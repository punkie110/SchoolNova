<head>

</head>
<body>
<form name = "Inwonersaantal" method = "post" action = "Overzicht.php"> 
<h2>Voer hier het minimale inwonersaantal in</h2><br />
<input type = "text" name = "Invoerveld">
<input type = "submit" value = "Bevestigen">


</body>