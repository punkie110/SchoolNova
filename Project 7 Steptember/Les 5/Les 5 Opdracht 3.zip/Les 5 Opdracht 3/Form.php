<head>

</head>
<body>
<form name = "LaptopMerk" method = "post" action = "Overzicht.php"> 
<h2>Voer hier Het latop merk, model of processor in.</h2><br />
<input type = "text" name = "Invoerveld">
<input type = "submit" value = "Bevestigen">


</body>