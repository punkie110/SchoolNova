<?php
if(isset($_COOKIE["taal"]))
{
    echo($_COOKIE["taal"]);
}
?>