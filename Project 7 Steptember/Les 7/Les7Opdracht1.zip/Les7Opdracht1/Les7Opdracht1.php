<?php
setcookie("taal", "nl", time() + 60, "/");
?>