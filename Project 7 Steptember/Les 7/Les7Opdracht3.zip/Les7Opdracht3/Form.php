<head>

</head>

<body>
<form name="Toevoegen" method="post" action="Pagina2.php">
    <h5>gebruikersnaam:</h5>
    <input type="text" name="gebruikersnaam"><br />
    <h5>wachtwoord:</h5>
    <input type="text" name="wachtwoord"><br />
    <input type="submit" value="Bevestigen">
</body>