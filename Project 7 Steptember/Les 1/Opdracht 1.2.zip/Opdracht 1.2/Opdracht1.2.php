<head>


</head>
<body>
<?php
include "fiets.php";
$fiets1 = new fiets("fiets1");
$fiets1 -> $type = "racefiets";
$fiets1 -> $elektrisch = true; 
$fiets1 -> $bandenspanning = 3.2;
$fiets1 -> $merk = "Cortina";
?>
</body>