<head>

</head>

<body>
    <table>
        <form name="Toevoegen" method="post" action="Overzicht.php">
            <h2>Voer hier een nieuwe provincie in</h2>
            <h5>Naam van de provincie:</h5>
            <input type="text" name="provincieNaam"><br />
            <h5>Hoofdstad:</h5>
            <input type="text" name="hoofdstad"><br />
            <h5>Populatie:</h5>
            <input type="text" name="populatie"><br />
            <h5>grootte in km2</h5>
            <input type="text" name="grootte"><br />
            <h5>Oprichtdatum</h5>
            <input type="text" name="oprichtdatum"><br />
            <input type="submit" value="Bevestigen">
    </table>
</body>