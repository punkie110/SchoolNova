﻿namespace justin_Munk_While_Lus_4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblWhileLus4 = new System.Windows.Forms.Label();
            this.lbx0tot9 = new System.Windows.Forms.ListBox();
            this.lbx90tot100 = new System.Windows.Forms.ListBox();
            this.lbx100tot90 = new System.Windows.Forms.ListBox();
            this.btnstatistiek1tot10 = new System.Windows.Forms.Button();
            this.btnstatistiek90tot100 = new System.Windows.Forms.Button();
            this.btnstatistiek100tot90 = new System.Windows.Forms.Button();
            this.lblgemiddelde1 = new System.Windows.Forms.Label();
            this.txtGemiddelde1 = new System.Windows.Forms.TextBox();
            this.lblTotaal1 = new System.Windows.Forms.Label();
            this.txtTotaal1 = new System.Windows.Forms.TextBox();
            this.lblGemiddelde2 = new System.Windows.Forms.Label();
            this.lblTotaal2 = new System.Windows.Forms.Label();
            this.txtGemiddelde2 = new System.Windows.Forms.TextBox();
            this.txtTotaal2 = new System.Windows.Forms.TextBox();
            this.lblGemiddelde3 = new System.Windows.Forms.Label();
            this.lblTotaal3 = new System.Windows.Forms.Label();
            this.txtGemiddelde3 = new System.Windows.Forms.TextBox();
            this.txtTotaal3 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblWhileLus4
            // 
            this.lblWhileLus4.AutoSize = true;
            this.lblWhileLus4.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWhileLus4.ForeColor = System.Drawing.Color.Red;
            this.lblWhileLus4.Location = new System.Drawing.Point(279, 39);
            this.lblWhileLus4.Name = "lblWhileLus4";
            this.lblWhileLus4.Size = new System.Drawing.Size(247, 51);
            this.lblWhileLus4.TabIndex = 0;
            this.lblWhileLus4.Text = "While Lus 4";
            // 
            // lbx0tot9
            // 
            this.lbx0tot9.FormattingEnabled = true;
            this.lbx0tot9.ItemHeight = 16;
            this.lbx0tot9.Location = new System.Drawing.Point(57, 111);
            this.lbx0tot9.Name = "lbx0tot9";
            this.lbx0tot9.Size = new System.Drawing.Size(184, 228);
            this.lbx0tot9.TabIndex = 1;
            // 
            // lbx90tot100
            // 
            this.lbx90tot100.FormattingEnabled = true;
            this.lbx90tot100.ItemHeight = 16;
            this.lbx90tot100.Location = new System.Drawing.Point(308, 111);
            this.lbx90tot100.Name = "lbx90tot100";
            this.lbx90tot100.Size = new System.Drawing.Size(184, 228);
            this.lbx90tot100.TabIndex = 2;
            // 
            // lbx100tot90
            // 
            this.lbx100tot90.FormattingEnabled = true;
            this.lbx100tot90.ItemHeight = 16;
            this.lbx100tot90.Location = new System.Drawing.Point(567, 111);
            this.lbx100tot90.Name = "lbx100tot90";
            this.lbx100tot90.Size = new System.Drawing.Size(184, 228);
            this.lbx100tot90.TabIndex = 3;
            // 
            // btnstatistiek1tot10
            // 
            this.btnstatistiek1tot10.Location = new System.Drawing.Point(57, 470);
            this.btnstatistiek1tot10.Name = "btnstatistiek1tot10";
            this.btnstatistiek1tot10.Size = new System.Drawing.Size(196, 65);
            this.btnstatistiek1tot10.TabIndex = 4;
            this.btnstatistiek1tot10.Text = "Geef statistiek 1 tot 10";
            this.btnstatistiek1tot10.UseVisualStyleBackColor = true;
            this.btnstatistiek1tot10.Click += new System.EventHandler(this.btnstatistiek1tot10_Click);
            // 
            // btnstatistiek90tot100
            // 
            this.btnstatistiek90tot100.Location = new System.Drawing.Point(296, 470);
            this.btnstatistiek90tot100.Name = "btnstatistiek90tot100";
            this.btnstatistiek90tot100.Size = new System.Drawing.Size(196, 65);
            this.btnstatistiek90tot100.TabIndex = 5;
            this.btnstatistiek90tot100.Text = "geef statistiek 90 tot 100";
            this.btnstatistiek90tot100.UseVisualStyleBackColor = true;
            this.btnstatistiek90tot100.Click += new System.EventHandler(this.btnstatistiek90tot100_Click);
            // 
            // btnstatistiek100tot90
            // 
            this.btnstatistiek100tot90.Location = new System.Drawing.Point(567, 470);
            this.btnstatistiek100tot90.Name = "btnstatistiek100tot90";
            this.btnstatistiek100tot90.Size = new System.Drawing.Size(196, 65);
            this.btnstatistiek100tot90.TabIndex = 6;
            this.btnstatistiek100tot90.Text = "geef statistiek 100 tot 90";
            this.btnstatistiek100tot90.UseVisualStyleBackColor = true;
            this.btnstatistiek100tot90.Click += new System.EventHandler(this.btnstatistiek100tot90_Click);
            // 
            // lblgemiddelde1
            // 
            this.lblgemiddelde1.AutoSize = true;
            this.lblgemiddelde1.Location = new System.Drawing.Point(12, 381);
            this.lblgemiddelde1.Name = "lblgemiddelde1";
            this.lblgemiddelde1.Size = new System.Drawing.Size(85, 16);
            this.lblgemiddelde1.TabIndex = 7;
            this.lblgemiddelde1.Text = "Gemiddelde:";
            // 
            // txtGemiddelde1
            // 
            this.txtGemiddelde1.Location = new System.Drawing.Point(123, 378);
            this.txtGemiddelde1.Name = "txtGemiddelde1";
            this.txtGemiddelde1.Size = new System.Drawing.Size(103, 22);
            this.txtGemiddelde1.TabIndex = 8;
            this.txtGemiddelde1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lblTotaal1
            // 
            this.lblTotaal1.AutoSize = true;
            this.lblTotaal1.Location = new System.Drawing.Point(31, 433);
            this.lblTotaal1.Name = "lblTotaal1";
            this.lblTotaal1.Size = new System.Drawing.Size(49, 16);
            this.lblTotaal1.TabIndex = 9;
            this.lblTotaal1.Text = "Totaal:";
            // 
            // txtTotaal1
            // 
            this.txtTotaal1.Location = new System.Drawing.Point(123, 427);
            this.txtTotaal1.Name = "txtTotaal1";
            this.txtTotaal1.Size = new System.Drawing.Size(103, 22);
            this.txtTotaal1.TabIndex = 10;
            // 
            // lblGemiddelde2
            // 
            this.lblGemiddelde2.AutoSize = true;
            this.lblGemiddelde2.Location = new System.Drawing.Point(248, 378);
            this.lblGemiddelde2.Name = "lblGemiddelde2";
            this.lblGemiddelde2.Size = new System.Drawing.Size(85, 16);
            this.lblGemiddelde2.TabIndex = 11;
            this.lblGemiddelde2.Text = "Gemiddelde:";
            // 
            // lblTotaal2
            // 
            this.lblTotaal2.AutoSize = true;
            this.lblTotaal2.Location = new System.Drawing.Point(284, 427);
            this.lblTotaal2.Name = "lblTotaal2";
            this.lblTotaal2.Size = new System.Drawing.Size(49, 16);
            this.lblTotaal2.TabIndex = 12;
            this.lblTotaal2.Text = "Totaal:";
            // 
            // txtGemiddelde2
            // 
            this.txtGemiddelde2.Location = new System.Drawing.Point(357, 378);
            this.txtGemiddelde2.Name = "txtGemiddelde2";
            this.txtGemiddelde2.Size = new System.Drawing.Size(103, 22);
            this.txtGemiddelde2.TabIndex = 13;
            // 
            // txtTotaal2
            // 
            this.txtTotaal2.Location = new System.Drawing.Point(357, 424);
            this.txtTotaal2.Name = "txtTotaal2";
            this.txtTotaal2.Size = new System.Drawing.Size(103, 22);
            this.txtTotaal2.TabIndex = 14;
            // 
            // lblGemiddelde3
            // 
            this.lblGemiddelde3.AutoSize = true;
            this.lblGemiddelde3.Location = new System.Drawing.Point(543, 378);
            this.lblGemiddelde3.Name = "lblGemiddelde3";
            this.lblGemiddelde3.Size = new System.Drawing.Size(85, 16);
            this.lblGemiddelde3.TabIndex = 15;
            this.lblGemiddelde3.Text = "Gemiddelde:";
            // 
            // lblTotaal3
            // 
            this.lblTotaal3.AutoSize = true;
            this.lblTotaal3.Location = new System.Drawing.Point(564, 424);
            this.lblTotaal3.Name = "lblTotaal3";
            this.lblTotaal3.Size = new System.Drawing.Size(49, 16);
            this.lblTotaal3.TabIndex = 16;
            this.lblTotaal3.Text = "Totaal:";
            // 
            // txtGemiddelde3
            // 
            this.txtGemiddelde3.Location = new System.Drawing.Point(648, 375);
            this.txtGemiddelde3.Name = "txtGemiddelde3";
            this.txtGemiddelde3.Size = new System.Drawing.Size(103, 22);
            this.txtGemiddelde3.TabIndex = 17;
            // 
            // txtTotaal3
            // 
            this.txtTotaal3.Location = new System.Drawing.Point(648, 421);
            this.txtTotaal3.Name = "txtTotaal3";
            this.txtTotaal3.Size = new System.Drawing.Size(103, 22);
            this.txtTotaal3.TabIndex = 18;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Khaki;
            this.ClientSize = new System.Drawing.Size(800, 598);
            this.Controls.Add(this.txtTotaal3);
            this.Controls.Add(this.txtGemiddelde3);
            this.Controls.Add(this.lblTotaal3);
            this.Controls.Add(this.lblGemiddelde3);
            this.Controls.Add(this.txtTotaal2);
            this.Controls.Add(this.txtGemiddelde2);
            this.Controls.Add(this.lblTotaal2);
            this.Controls.Add(this.lblGemiddelde2);
            this.Controls.Add(this.txtTotaal1);
            this.Controls.Add(this.lblTotaal1);
            this.Controls.Add(this.txtGemiddelde1);
            this.Controls.Add(this.lblgemiddelde1);
            this.Controls.Add(this.btnstatistiek100tot90);
            this.Controls.Add(this.btnstatistiek90tot100);
            this.Controls.Add(this.btnstatistiek1tot10);
            this.Controls.Add(this.lbx100tot90);
            this.Controls.Add(this.lbx90tot100);
            this.Controls.Add(this.lbx0tot9);
            this.Controls.Add(this.lblWhileLus4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblWhileLus4;
        private System.Windows.Forms.ListBox lbx0tot9;
        private System.Windows.Forms.ListBox lbx90tot100;
        private System.Windows.Forms.ListBox lbx100tot90;
        private System.Windows.Forms.Button btnstatistiek1tot10;
        private System.Windows.Forms.Button btnstatistiek90tot100;
        private System.Windows.Forms.Button btnstatistiek100tot90;
        private System.Windows.Forms.Label lblgemiddelde1;
        private System.Windows.Forms.TextBox txtGemiddelde1;
        private System.Windows.Forms.Label lblTotaal1;
        private System.Windows.Forms.TextBox txtTotaal1;
        private System.Windows.Forms.Label lblGemiddelde2;
        private System.Windows.Forms.Label lblTotaal2;
        private System.Windows.Forms.TextBox txtGemiddelde2;
        private System.Windows.Forms.TextBox txtTotaal2;
        private System.Windows.Forms.Label lblGemiddelde3;
        private System.Windows.Forms.Label lblTotaal3;
        private System.Windows.Forms.TextBox txtGemiddelde3;
        private System.Windows.Forms.TextBox txtTotaal3;
    }
}

