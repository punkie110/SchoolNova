﻿using System;
using System.Windows.Forms;

//Les				    : 4. do-while lus
//                      : Raden van een getal
//
//Software developer    : Yildiz Kurt
//versie			    : 2.1
//Klas				    : SD1
//Datum                 : dinsdag 11 juli 2023


namespace JouwnaamDoWhileLus3
{

    public partial class frmJouwnaamDoWhileLus : Form
    {
        //Declareren en initialeren van variabelen.
        //Later leren je waarom je variabelen private maakt.
        private int gekozenGetal;
        private Random random; 
        private int targetNummer;

        public frmJouwnaamDoWhileLus()
        {
            InitializeComponent();

            //Zorgt voor dat het programma een cijfer tussen de 1 en 101 kiest en plaats het in de variabele targetNummer.
            random = new Random();
            targetNummer = random.Next(1, 101);
        }

        private void btResultaat_Click(object sender, EventArgs e)
        {
                gekozenGetal = int.Parse(txtGetal.Text);

                if (gekozenGetal < targetNummer)
                {
                    txtResultaat.Text = "Het getal is te laag. Probeer opnieuw.";
                }
                else if (gekozenGetal > targetNummer)
                {
                    txtResultaat.Text = "Het getal is te hoog. Probeer opnieuw.";
                }
                else
                {
                    txtResultaat.Text = "Gefeliciteerd! Je hebt het juiste getal geraden: " + targetNummer;
                }
            
        }
    }
}