﻿
namespace JouwnaamDoWhileLus3
{
    partial class frmJouwnaamDoWhileLus
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblDoWhile = new System.Windows.Forms.Label();
            this.lblGetal = new System.Windows.Forms.Label();
            this.txtGetal = new System.Windows.Forms.TextBox();
            this.txtResultaat = new System.Windows.Forms.TextBox();
            this.btResultaat = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblDoWhile
            // 
            this.lblDoWhile.AutoSize = true;
            this.lblDoWhile.Font = new System.Drawing.Font("Berlin Sans FB", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDoWhile.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblDoWhile.Location = new System.Drawing.Point(47, 9);
            this.lblDoWhile.Name = "lblDoWhile";
            this.lblDoWhile.Size = new System.Drawing.Size(300, 71);
            this.lblDoWhile.TabIndex = 0;
            this.lblDoWhile.Text = "DoWhile 3";
            // 
            // lblGetal
            // 
            this.lblGetal.AutoSize = true;
            this.lblGetal.Location = new System.Drawing.Point(51, 359);
            this.lblGetal.Name = "lblGetal";
            this.lblGetal.Size = new System.Drawing.Size(90, 26);
            this.lblGetal.TabIndex = 1;
            this.lblGetal.Text = "Raad het getal \r\ntussen 1 t/m 100:";
            // 
            // txtGetal
            // 
            this.txtGetal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGetal.Location = new System.Drawing.Point(157, 359);
            this.txtGetal.Name = "txtGetal";
            this.txtGetal.Size = new System.Drawing.Size(79, 26);
            this.txtGetal.TabIndex = 3;
            // 
            // txtResultaat
            // 
            this.txtResultaat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtResultaat.Location = new System.Drawing.Point(358, 305);
            this.txtResultaat.Multiline = true;
            this.txtResultaat.Name = "txtResultaat";
            this.txtResultaat.ReadOnly = true;
            this.txtResultaat.Size = new System.Drawing.Size(288, 80);
            this.txtResultaat.TabIndex = 5;
            // 
            // btResultaat
            // 
            this.btResultaat.Font = new System.Drawing.Font("Berlin Sans FB", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btResultaat.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btResultaat.Location = new System.Drawing.Point(251, 305);
            this.btResultaat.Name = "btResultaat";
            this.btResultaat.Size = new System.Drawing.Size(96, 80);
            this.btResultaat.TabIndex = 6;
            this.btResultaat.Text = "Raad het getal";
            this.btResultaat.UseVisualStyleBackColor = true;
            this.btResultaat.Click += new System.EventHandler(this.btResultaat_Click);
            // 
            // frmJouwnaamDoWhileLus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(676, 411);
            this.Controls.Add(this.btResultaat);
            this.Controls.Add(this.txtResultaat);
            this.Controls.Add(this.txtGetal);
            this.Controls.Add(this.lblGetal);
            this.Controls.Add(this.lblDoWhile);
            this.Name = "frmJouwnaamDoWhileLus";
            this.Text = "Do While";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblDoWhile;
        private System.Windows.Forms.Label lblGetal;
        private System.Windows.Forms.TextBox txtGetal;
        private System.Windows.Forms.TextBox txtResultaat;
        private System.Windows.Forms.Button btResultaat;
    }
}

