﻿namespace JustinMunkOpdracht4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtInput = new System.Windows.Forms.TextBox();
            this.lblCijfer = new System.Windows.Forms.Label();
            this.lbxCijfers = new System.Windows.Forms.ListBox();
            this.btnStatistiek = new System.Windows.Forms.Button();
            this.lblForLus = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtInput
            // 
            this.txtInput.Location = new System.Drawing.Point(289, 52);
            this.txtInput.Name = "txtInput";
            this.txtInput.Size = new System.Drawing.Size(160, 22);
            this.txtInput.TabIndex = 0;
            // 
            // lblCijfer
            // 
            this.lblCijfer.AutoSize = true;
            this.lblCijfer.Location = new System.Drawing.Point(154, 52);
            this.lblCijfer.Name = "lblCijfer";
            this.lblCijfer.Size = new System.Drawing.Size(40, 16);
            this.lblCijfer.TabIndex = 1;
            this.lblCijfer.Text = "Cijfer:";
            // 
            // lbxCijfers
            // 
            this.lbxCijfers.FormattingEnabled = true;
            this.lbxCijfers.ItemHeight = 16;
            this.lbxCijfers.Location = new System.Drawing.Point(292, 123);
            this.lbxCijfers.Name = "lbxCijfers";
            this.lbxCijfers.Size = new System.Drawing.Size(156, 212);
            this.lbxCijfers.TabIndex = 2;
            // 
            // btnStatistiek
            // 
            this.btnStatistiek.Location = new System.Drawing.Point(282, 362);
            this.btnStatistiek.Name = "btnStatistiek";
            this.btnStatistiek.Size = new System.Drawing.Size(167, 55);
            this.btnStatistiek.TabIndex = 3;
            this.btnStatistiek.Text = "Geef Statistiek";
            this.btnStatistiek.UseVisualStyleBackColor = true;
            this.btnStatistiek.Click += new System.EventHandler(this.btnStatistiek_Click);
            // 
            // lblForLus
            // 
            this.lblForLus.AutoSize = true;
            this.lblForLus.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblForLus.ForeColor = System.Drawing.Color.Fuchsia;
            this.lblForLus.Location = new System.Drawing.Point(565, 84);
            this.lblForLus.Name = "lblForLus";
            this.lblForLus.Size = new System.Drawing.Size(182, 54);
            this.lblForLus.TabIndex = 4;
            this.lblForLus.Text = "For Lus";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblForLus);
            this.Controls.Add(this.btnStatistiek);
            this.Controls.Add(this.lbxCijfers);
            this.Controls.Add(this.lblCijfer);
            this.Controls.Add(this.txtInput);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtInput;
        private System.Windows.Forms.Label lblCijfer;
        private System.Windows.Forms.ListBox lbxCijfers;
        private System.Windows.Forms.Button btnStatistiek;
        private System.Windows.Forms.Label lblForLus;
    }
}

