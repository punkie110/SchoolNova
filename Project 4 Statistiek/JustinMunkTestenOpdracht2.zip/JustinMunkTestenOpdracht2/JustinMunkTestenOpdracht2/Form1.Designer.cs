﻿namespace JustinMunkTestenOpdracht2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtAndTrueFalse = new System.Windows.Forms.TextBox();
            this.txtOrTrueFalse = new System.Windows.Forms.TextBox();
            this.txtKleinerDan1 = new System.Windows.Forms.TextBox();
            this.txtAnd1 = new System.Windows.Forms.TextBox();
            this.txtOr1 = new System.Windows.Forms.TextBox();
            this.txtGroterDan2 = new System.Windows.Forms.TextBox();
            this.txtKleinerDan2 = new System.Windows.Forms.TextBox();
            this.txtAnd2 = new System.Windows.Forms.TextBox();
            this.txtGroterDanTrueFalse = new System.Windows.Forms.TextBox();
            this.txtKleinerDanTrueFalse = new System.Windows.Forms.TextBox();
            this.txtOr2 = new System.Windows.Forms.TextBox();
            this.txtGroterDan1 = new System.Windows.Forms.TextBox();
            this.btnResultaat = new System.Windows.Forms.Button();
            this.lblKleinerDan = new System.Windows.Forms.Label();
            this.lblAnd = new System.Windows.Forms.Label();
            this.lblOr = new System.Windows.Forms.Label();
            this.lblGroterDan = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtAndTrueFalse
            // 
            this.txtAndTrueFalse.Location = new System.Drawing.Point(652, 235);
            this.txtAndTrueFalse.Name = "txtAndTrueFalse";
            this.txtAndTrueFalse.Size = new System.Drawing.Size(123, 22);
            this.txtAndTrueFalse.TabIndex = 33;
            // 
            // txtOrTrueFalse
            // 
            this.txtOrTrueFalse.Location = new System.Drawing.Point(652, 281);
            this.txtOrTrueFalse.Name = "txtOrTrueFalse";
            this.txtOrTrueFalse.Size = new System.Drawing.Size(123, 22);
            this.txtOrTrueFalse.TabIndex = 32;
            // 
            // txtKleinerDan1
            // 
            this.txtKleinerDan1.Location = new System.Drawing.Point(25, 190);
            this.txtKleinerDan1.Name = "txtKleinerDan1";
            this.txtKleinerDan1.Size = new System.Drawing.Size(123, 22);
            this.txtKleinerDan1.TabIndex = 31;
            // 
            // txtAnd1
            // 
            this.txtAnd1.Location = new System.Drawing.Point(25, 241);
            this.txtAnd1.Name = "txtAnd1";
            this.txtAnd1.Size = new System.Drawing.Size(123, 22);
            this.txtAnd1.TabIndex = 30;
            // 
            // txtOr1
            // 
            this.txtOr1.Location = new System.Drawing.Point(25, 287);
            this.txtOr1.Name = "txtOr1";
            this.txtOr1.Size = new System.Drawing.Size(123, 22);
            this.txtOr1.TabIndex = 29;
            // 
            // txtGroterDan2
            // 
            this.txtGroterDan2.Location = new System.Drawing.Point(310, 141);
            this.txtGroterDan2.Name = "txtGroterDan2";
            this.txtGroterDan2.Size = new System.Drawing.Size(123, 22);
            this.txtGroterDan2.TabIndex = 28;
            // 
            // txtKleinerDan2
            // 
            this.txtKleinerDan2.Location = new System.Drawing.Point(310, 190);
            this.txtKleinerDan2.Name = "txtKleinerDan2";
            this.txtKleinerDan2.Size = new System.Drawing.Size(123, 22);
            this.txtKleinerDan2.TabIndex = 27;
            // 
            // txtAnd2
            // 
            this.txtAnd2.Location = new System.Drawing.Point(310, 238);
            this.txtAnd2.Name = "txtAnd2";
            this.txtAnd2.Size = new System.Drawing.Size(123, 22);
            this.txtAnd2.TabIndex = 26;
            // 
            // txtGroterDanTrueFalse
            // 
            this.txtGroterDanTrueFalse.Location = new System.Drawing.Point(652, 141);
            this.txtGroterDanTrueFalse.Name = "txtGroterDanTrueFalse";
            this.txtGroterDanTrueFalse.Size = new System.Drawing.Size(123, 22);
            this.txtGroterDanTrueFalse.TabIndex = 25;
            // 
            // txtKleinerDanTrueFalse
            // 
            this.txtKleinerDanTrueFalse.Location = new System.Drawing.Point(652, 187);
            this.txtKleinerDanTrueFalse.Name = "txtKleinerDanTrueFalse";
            this.txtKleinerDanTrueFalse.Size = new System.Drawing.Size(123, 22);
            this.txtKleinerDanTrueFalse.TabIndex = 24;
            // 
            // txtOr2
            // 
            this.txtOr2.Location = new System.Drawing.Point(310, 284);
            this.txtOr2.Name = "txtOr2";
            this.txtOr2.Size = new System.Drawing.Size(123, 22);
            this.txtOr2.TabIndex = 23;
            // 
            // txtGroterDan1
            // 
            this.txtGroterDan1.Location = new System.Drawing.Point(25, 144);
            this.txtGroterDan1.Name = "txtGroterDan1";
            this.txtGroterDan1.Size = new System.Drawing.Size(123, 22);
            this.txtGroterDan1.TabIndex = 22;
            // 
            // btnResultaat
            // 
            this.btnResultaat.Location = new System.Drawing.Point(452, 147);
            this.btnResultaat.Name = "btnResultaat";
            this.btnResultaat.Size = new System.Drawing.Size(182, 156);
            this.btnResultaat.TabIndex = 21;
            this.btnResultaat.Text = "Resultaat";
            this.btnResultaat.UseVisualStyleBackColor = true;
            this.btnResultaat.Click += new System.EventHandler(this.btnResultaat_Click);
            // 
            // lblKleinerDan
            // 
            this.lblKleinerDan.AutoSize = true;
            this.lblKleinerDan.Location = new System.Drawing.Point(204, 190);
            this.lblKleinerDan.Name = "lblKleinerDan";
            this.lblKleinerDan.Size = new System.Drawing.Size(94, 16);
            this.lblKleinerDan.TabIndex = 20;
            this.lblKleinerDan.Text = "Kleiner Dan (<)";
            // 
            // lblAnd
            // 
            this.lblAnd.AutoSize = true;
            this.lblAnd.Location = new System.Drawing.Point(231, 241);
            this.lblAnd.Name = "lblAnd";
            this.lblAnd.Size = new System.Drawing.Size(36, 16);
            this.lblAnd.TabIndex = 19;
            this.lblAnd.Text = "AND";
            // 
            // lblOr
            // 
            this.lblOr.AutoSize = true;
            this.lblOr.Location = new System.Drawing.Point(231, 287);
            this.lblOr.Name = "lblOr";
            this.lblOr.Size = new System.Drawing.Size(27, 16);
            this.lblOr.TabIndex = 18;
            this.lblOr.Text = "OR";
            // 
            // lblGroterDan
            // 
            this.lblGroterDan.AutoSize = true;
            this.lblGroterDan.Location = new System.Drawing.Point(204, 144);
            this.lblGroterDan.Name = "lblGroterDan";
            this.lblGroterDan.Size = new System.Drawing.Size(88, 16);
            this.lblGroterDan.TabIndex = 17;
            this.lblGroterDan.Text = "Groter dan (>)";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtAndTrueFalse);
            this.Controls.Add(this.txtOrTrueFalse);
            this.Controls.Add(this.txtKleinerDan1);
            this.Controls.Add(this.txtAnd1);
            this.Controls.Add(this.txtOr1);
            this.Controls.Add(this.txtGroterDan2);
            this.Controls.Add(this.txtKleinerDan2);
            this.Controls.Add(this.txtAnd2);
            this.Controls.Add(this.txtGroterDanTrueFalse);
            this.Controls.Add(this.txtKleinerDanTrueFalse);
            this.Controls.Add(this.txtOr2);
            this.Controls.Add(this.txtGroterDan1);
            this.Controls.Add(this.btnResultaat);
            this.Controls.Add(this.lblKleinerDan);
            this.Controls.Add(this.lblAnd);
            this.Controls.Add(this.lblOr);
            this.Controls.Add(this.lblGroterDan);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtAndTrueFalse;
        private System.Windows.Forms.TextBox txtOrTrueFalse;
        private System.Windows.Forms.TextBox txtKleinerDan1;
        private System.Windows.Forms.TextBox txtAnd1;
        private System.Windows.Forms.TextBox txtOr1;
        private System.Windows.Forms.TextBox txtGroterDan2;
        private System.Windows.Forms.TextBox txtKleinerDan2;
        private System.Windows.Forms.TextBox txtAnd2;
        private System.Windows.Forms.TextBox txtGroterDanTrueFalse;
        private System.Windows.Forms.TextBox txtKleinerDanTrueFalse;
        private System.Windows.Forms.TextBox txtOr2;
        private System.Windows.Forms.TextBox txtGroterDan1;
        private System.Windows.Forms.Button btnResultaat;
        private System.Windows.Forms.Label lblKleinerDan;
        private System.Windows.Forms.Label lblAnd;
        private System.Windows.Forms.Label lblOr;
        private System.Windows.Forms.Label lblGroterDan;
    }
}

