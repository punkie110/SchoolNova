﻿namespace JustinMunkOpdracht2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAdvies = new System.Windows.Forms.Button();
            this.lbxCijfers = new System.Windows.Forms.ListBox();
            this.lblForLus = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnAdvies
            // 
            this.btnAdvies.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdvies.Location = new System.Drawing.Point(239, 273);
            this.btnAdvies.Name = "btnAdvies";
            this.btnAdvies.Size = new System.Drawing.Size(277, 74);
            this.btnAdvies.TabIndex = 0;
            this.btnAdvies.Text = "Geef Advies";
            this.btnAdvies.UseVisualStyleBackColor = true;
            this.btnAdvies.Click += new System.EventHandler(this.btnAdvies_Click);
            // 
            // lbxCijfers
            // 
            this.lbxCijfers.FormattingEnabled = true;
            this.lbxCijfers.ItemHeight = 16;
            this.lbxCijfers.Location = new System.Drawing.Point(238, 64);
            this.lbxCijfers.Name = "lbxCijfers";
            this.lbxCijfers.Size = new System.Drawing.Size(278, 180);
            this.lbxCijfers.TabIndex = 1;
            // 
            // lblForLus
            // 
            this.lblForLus.AutoSize = true;
            this.lblForLus.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblForLus.ForeColor = System.Drawing.Color.Fuchsia;
            this.lblForLus.Location = new System.Drawing.Point(270, -8);
            this.lblForLus.Name = "lblForLus";
            this.lblForLus.Size = new System.Drawing.Size(213, 69);
            this.lblForLus.TabIndex = 2;
            this.lblForLus.Text = "For lus";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblForLus);
            this.Controls.Add(this.lbxCijfers);
            this.Controls.Add(this.btnAdvies);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAdvies;
        private System.Windows.Forms.ListBox lbxCijfers;
        private System.Windows.Forms.Label lblForLus;
    }
}

