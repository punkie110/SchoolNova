﻿namespace JustinMunkEindopdrachtBommenGranaten
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblDobbel1 = new System.Windows.Forms.Label();
            this.lblDobbel8 = new System.Windows.Forms.Label();
            this.lblDobbel7 = new System.Windows.Forms.Label();
            this.lblDobbel6 = new System.Windows.Forms.Label();
            this.lblDobbel5 = new System.Windows.Forms.Label();
            this.lblDobbel4 = new System.Windows.Forms.Label();
            this.lblDobbel3 = new System.Windows.Forms.Label();
            this.lblDobbel2 = new System.Windows.Forms.Label();
            this.btnGooi = new System.Windows.Forms.Button();
            this.lblScore = new System.Windows.Forms.Label();
            this.lblScoreGetal = new System.Windows.Forms.Label();
            this.pnlTutorial = new System.Windows.Forms.Panel();
            this.lbl0Punten = new System.Windows.Forms.Label();
            this.lblUitlegSchedel = new System.Windows.Forms.Label();
            this.lblUitlegLichtZwaard = new System.Windows.Forms.Label();
            this.lblUitlegCockatoo = new System.Windows.Forms.Label();
            this.lblUitlegAap = new System.Windows.Forms.Label();
            this.lblUitlegDiamant = new System.Windows.Forms.Label();
            this.lblUitlegMunt = new System.Windows.Forms.Label();
            this.lblUitleg1 = new System.Windows.Forms.Label();
            this.pbxTutorial2 = new System.Windows.Forms.PictureBox();
            this.pbxUitleg5 = new System.Windows.Forms.PictureBox();
            this.pbxUitleg6 = new System.Windows.Forms.PictureBox();
            this.pbxUitleg4 = new System.Windows.Forms.PictureBox();
            this.pbxUitleg1 = new System.Windows.Forms.PictureBox();
            this.pbxUitleg2 = new System.Windows.Forms.PictureBox();
            this.pbxUitleg3 = new System.Windows.Forms.PictureBox();
            this.lblUitleg = new System.Windows.Forms.Label();
            this.lblScoreErbij = new System.Windows.Forms.Label();
            this.pbxTutorial = new System.Windows.Forms.PictureBox();
            this.pbxDobbel5 = new System.Windows.Forms.PictureBox();
            this.pbxDobbel2 = new System.Windows.Forms.PictureBox();
            this.pbxDobbel3 = new System.Windows.Forms.PictureBox();
            this.pbxDobbel4 = new System.Windows.Forms.PictureBox();
            this.pbxDobbel8 = new System.Windows.Forms.PictureBox();
            this.pbxDobbel7 = new System.Windows.Forms.PictureBox();
            this.pbxDobbel6 = new System.Windows.Forms.PictureBox();
            this.pbxDobbel1 = new System.Windows.Forms.PictureBox();
            this.pbxBackground = new System.Windows.Forms.PictureBox();
            this.pnlTutorial.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxTutorial2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxUitleg5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxUitleg6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxUitleg4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxUitleg1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxUitleg2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxUitleg3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxTutorial)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDobbel5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDobbel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDobbel3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDobbel4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDobbel8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDobbel7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDobbel6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDobbel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxBackground)).BeginInit();
            this.SuspendLayout();
            // 
            // lblDobbel1
            // 
            this.lblDobbel1.AutoSize = true;
            this.lblDobbel1.Location = new System.Drawing.Point(55, 73);
            this.lblDobbel1.Name = "lblDobbel1";
            this.lblDobbel1.Size = new System.Drawing.Size(98, 16);
            this.lblDobbel1.TabIndex = 0;
            this.lblDobbel1.Text = "Dobbelsteen 1:";
            // 
            // lblDobbel8
            // 
            this.lblDobbel8.AutoSize = true;
            this.lblDobbel8.Location = new System.Drawing.Point(1221, 73);
            this.lblDobbel8.Name = "lblDobbel8";
            this.lblDobbel8.Size = new System.Drawing.Size(98, 16);
            this.lblDobbel8.TabIndex = 6;
            this.lblDobbel8.Text = "Dobbelsteen 8:";
            // 
            // lblDobbel7
            // 
            this.lblDobbel7.AutoSize = true;
            this.lblDobbel7.Location = new System.Drawing.Point(1022, 73);
            this.lblDobbel7.Name = "lblDobbel7";
            this.lblDobbel7.Size = new System.Drawing.Size(98, 16);
            this.lblDobbel7.TabIndex = 7;
            this.lblDobbel7.Text = "Dobbelsteen 7:";
            // 
            // lblDobbel6
            // 
            this.lblDobbel6.AutoSize = true;
            this.lblDobbel6.Location = new System.Drawing.Point(867, 73);
            this.lblDobbel6.Name = "lblDobbel6";
            this.lblDobbel6.Size = new System.Drawing.Size(98, 16);
            this.lblDobbel6.TabIndex = 8;
            this.lblDobbel6.Text = "Dobbelsteen 6:";
            // 
            // lblDobbel5
            // 
            this.lblDobbel5.AutoSize = true;
            this.lblDobbel5.Location = new System.Drawing.Point(696, 73);
            this.lblDobbel5.Name = "lblDobbel5";
            this.lblDobbel5.Size = new System.Drawing.Size(98, 16);
            this.lblDobbel5.TabIndex = 9;
            this.lblDobbel5.Text = "Dobbelsteen 5:";
            // 
            // lblDobbel4
            // 
            this.lblDobbel4.AutoSize = true;
            this.lblDobbel4.Location = new System.Drawing.Point(531, 73);
            this.lblDobbel4.Name = "lblDobbel4";
            this.lblDobbel4.Size = new System.Drawing.Size(98, 16);
            this.lblDobbel4.TabIndex = 10;
            this.lblDobbel4.Text = "Dobbelsteen 4:";
            // 
            // lblDobbel3
            // 
            this.lblDobbel3.AutoSize = true;
            this.lblDobbel3.Location = new System.Drawing.Point(374, 73);
            this.lblDobbel3.Name = "lblDobbel3";
            this.lblDobbel3.Size = new System.Drawing.Size(98, 16);
            this.lblDobbel3.TabIndex = 11;
            this.lblDobbel3.Text = "Dobbelsteen 3:";
            // 
            // lblDobbel2
            // 
            this.lblDobbel2.AutoSize = true;
            this.lblDobbel2.Location = new System.Drawing.Point(214, 73);
            this.lblDobbel2.Name = "lblDobbel2";
            this.lblDobbel2.Size = new System.Drawing.Size(98, 16);
            this.lblDobbel2.TabIndex = 12;
            this.lblDobbel2.Text = "Dobbelsteen 2:";
            // 
            // btnGooi
            // 
            this.btnGooi.Font = new System.Drawing.Font("MS Reference Sans Serif", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGooi.Location = new System.Drawing.Point(516, 331);
            this.btnGooi.Name = "btnGooi";
            this.btnGooi.Size = new System.Drawing.Size(351, 107);
            this.btnGooi.TabIndex = 21;
            this.btnGooi.Text = "Gooi";
            this.btnGooi.UseVisualStyleBackColor = true;
            this.btnGooi.Click += new System.EventHandler(this.btnGooi_Click);
            // 
            // lblScore
            // 
            this.lblScore.AutoSize = true;
            this.lblScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScore.Location = new System.Drawing.Point(1098, 368);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(112, 38);
            this.lblScore.TabIndex = 22;
            this.lblScore.Text = "Score:";
            // 
            // lblScoreGetal
            // 
            this.lblScoreGetal.AutoSize = true;
            this.lblScoreGetal.Location = new System.Drawing.Point(1251, 386);
            this.lblScoreGetal.Name = "lblScoreGetal";
            this.lblScoreGetal.Size = new System.Drawing.Size(14, 16);
            this.lblScoreGetal.TabIndex = 23;
            this.lblScoreGetal.Text = "0";
            // 
            // pnlTutorial
            // 
            this.pnlTutorial.Controls.Add(this.lbl0Punten);
            this.pnlTutorial.Controls.Add(this.lblUitlegSchedel);
            this.pnlTutorial.Controls.Add(this.lblUitlegLichtZwaard);
            this.pnlTutorial.Controls.Add(this.lblUitlegCockatoo);
            this.pnlTutorial.Controls.Add(this.lblUitlegAap);
            this.pnlTutorial.Controls.Add(this.lblUitlegDiamant);
            this.pnlTutorial.Controls.Add(this.lblUitlegMunt);
            this.pnlTutorial.Controls.Add(this.lblUitleg1);
            this.pnlTutorial.Controls.Add(this.pbxTutorial2);
            this.pnlTutorial.Controls.Add(this.pbxUitleg5);
            this.pnlTutorial.Controls.Add(this.pbxUitleg6);
            this.pnlTutorial.Controls.Add(this.pbxUitleg4);
            this.pnlTutorial.Controls.Add(this.pbxUitleg1);
            this.pnlTutorial.Controls.Add(this.pbxUitleg2);
            this.pnlTutorial.Controls.Add(this.pbxUitleg3);
            this.pnlTutorial.Controls.Add(this.lblUitleg);
            this.pnlTutorial.Location = new System.Drawing.Point(0, 1);
            this.pnlTutorial.Name = "pnlTutorial";
            this.pnlTutorial.Size = new System.Drawing.Size(1427, 450);
            this.pnlTutorial.TabIndex = 25;
            // 
            // lbl0Punten
            // 
            this.lbl0Punten.AutoSize = true;
            this.lbl0Punten.Font = new System.Drawing.Font("MV Boli", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0Punten.Location = new System.Drawing.Point(831, 402);
            this.lbl0Punten.Name = "lbl0Punten";
            this.lbl0Punten.Size = new System.Drawing.Size(570, 37);
            this.lbl0Punten.TabIndex = 15;
            this.lbl0Punten.Text = "0 PUNTEN VOOR DE TOTALE WORP!";
            // 
            // lblUitlegSchedel
            // 
            this.lblUitlegSchedel.AutoSize = true;
            this.lblUitlegSchedel.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUitlegSchedel.Location = new System.Drawing.Point(1034, 324);
            this.lblUitlegSchedel.Name = "lblUitlegSchedel";
            this.lblUitlegSchedel.Size = new System.Drawing.Size(383, 78);
            this.lblUitlegSchedel.TabIndex = 14;
            this.lblUitlegSchedel.Text = "schedels = slecht\r\n0 schedels per worp = 500 punten\r\n3 schedels per worp = ";
            // 
            // lblUitlegLichtZwaard
            // 
            this.lblUitlegLichtZwaard.AutoSize = true;
            this.lblUitlegLichtZwaard.Font = new System.Drawing.Font("MV Boli", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUitlegLichtZwaard.Location = new System.Drawing.Point(1052, 181);
            this.lblUitlegLichtZwaard.Name = "lblUitlegLichtZwaard";
            this.lblUitlegLichtZwaard.Size = new System.Drawing.Size(271, 132);
            this.lblUitlegLichtZwaard.TabIndex = 13;
            this.lblUitlegLichtZwaard.Text = "+100 voor 3 Lichtzwaarden\r\n+200 voor 4 Lichtzwaarden\r\n+500 voor 5 Lichtzwaarden\r\n" +
    "+1000 voor 6 Lichtzwaarden\r\n+2000 voor 7 Lichtzwaarden\r\n+4000 voor 8 Lichtzwaard" +
    "en\r\n";
            // 
            // lblUitlegCockatoo
            // 
            this.lblUitlegCockatoo.AutoSize = true;
            this.lblUitlegCockatoo.Font = new System.Drawing.Font("MV Boli", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUitlegCockatoo.Location = new System.Drawing.Point(1052, 38);
            this.lblUitlegCockatoo.Name = "lblUitlegCockatoo";
            this.lblUitlegCockatoo.Size = new System.Drawing.Size(234, 132);
            this.lblUitlegCockatoo.TabIndex = 12;
            this.lblUitlegCockatoo.Text = "+100 voor 3 Cockatoos\r\n+200 voor 4 Cockatoos\r\n+500 voor 5 Cockatoos\r\n+1000 voor 6" +
    " Cockatoos\r\n+2000 voor 7 Cockatoos\r\n+4000 voor 8 Cockatoos\r\n";
            // 
            // lblUitlegAap
            // 
            this.lblUitlegAap.AutoSize = true;
            this.lblUitlegAap.Font = new System.Drawing.Font("MV Boli", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUitlegAap.Location = new System.Drawing.Point(592, 299);
            this.lblUitlegAap.Name = "lblUitlegAap";
            this.lblUitlegAap.Size = new System.Drawing.Size(188, 132);
            this.lblUitlegAap.TabIndex = 11;
            this.lblUitlegAap.Text = "+100 voor 3 Apen\r\n+200 voor 4 apen\r\n+500 voor 5 apen\r\n+1000 voor 6 apen\r\n+2000 vo" +
    "or 7 apen\r\n+4000 voor 8 apen\r\n";
            // 
            // lblUitlegDiamant
            // 
            this.lblUitlegDiamant.AutoSize = true;
            this.lblUitlegDiamant.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUitlegDiamant.Location = new System.Drawing.Point(602, 228);
            this.lblUitlegDiamant.Name = "lblUitlegDiamant";
            this.lblUitlegDiamant.Size = new System.Drawing.Size(214, 52);
            this.lblUitlegDiamant.TabIndex = 10;
            this.lblUitlegDiamant.Text = "+100 punten\r\n voor elke Diamant";
            // 
            // lblUitlegMunt
            // 
            this.lblUitlegMunt.AutoSize = true;
            this.lblUitlegMunt.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUitlegMunt.Location = new System.Drawing.Point(602, 102);
            this.lblUitlegMunt.Name = "lblUitlegMunt";
            this.lblUitlegMunt.Size = new System.Drawing.Size(185, 52);
            this.lblUitlegMunt.TabIndex = 9;
            this.lblUitlegMunt.Text = "+100 punten\r\n voor elke Munt";
            // 
            // lblUitleg1
            // 
            this.lblUitleg1.AutoSize = true;
            this.lblUitleg1.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUitleg1.Location = new System.Drawing.Point(3, 7);
            this.lblUitleg1.Name = "lblUitleg1";
            this.lblUitleg1.Size = new System.Drawing.Size(571, 78);
            this.lblUitleg1.TabIndex = 8;
            this.lblUitleg1.Text = "Welkom bij bommen en granaten!\r\n In dit spel is het doel om 6000 punten te krijge" +
    "n \r\nin zo weinig mogelijk worpen.";
            // 
            // pbxTutorial2
            // 
            this.pbxTutorial2.Image = global::JustinMunkEindopdrachtBommenGranaten.Properties.Resources.Vraagteken;
            this.pbxTutorial2.Location = new System.Drawing.Point(14, 330);
            this.pbxTutorial2.Name = "pbxTutorial2";
            this.pbxTutorial2.Size = new System.Drawing.Size(154, 101);
            this.pbxTutorial2.TabIndex = 7;
            this.pbxTutorial2.TabStop = false;
            this.pbxTutorial2.Click += new System.EventHandler(this.pbxTutorial2_Click);
            // 
            // pbxUitleg5
            // 
            this.pbxUitleg5.Image = global::JustinMunkEindopdrachtBommenGranaten.Properties.Resources.lightsabers;
            this.pbxUitleg5.Location = new System.Drawing.Point(877, 204);
            this.pbxUitleg5.Name = "pbxUitleg5";
            this.pbxUitleg5.Size = new System.Drawing.Size(151, 84);
            this.pbxUitleg5.TabIndex = 6;
            this.pbxUitleg5.TabStop = false;
            // 
            // pbxUitleg6
            // 
            this.pbxUitleg6.Image = global::JustinMunkEindopdrachtBommenGranaten.Properties.Resources.schedel;
            this.pbxUitleg6.Location = new System.Drawing.Point(877, 314);
            this.pbxUitleg6.Name = "pbxUitleg6";
            this.pbxUitleg6.Size = new System.Drawing.Size(151, 84);
            this.pbxUitleg6.TabIndex = 5;
            this.pbxUitleg6.TabStop = false;
            // 
            // pbxUitleg4
            // 
            this.pbxUitleg4.Image = global::JustinMunkEindopdrachtBommenGranaten.Properties.Resources.cockatoo;
            this.pbxUitleg4.Location = new System.Drawing.Point(877, 88);
            this.pbxUitleg4.Name = "pbxUitleg4";
            this.pbxUitleg4.Size = new System.Drawing.Size(151, 84);
            this.pbxUitleg4.TabIndex = 4;
            this.pbxUitleg4.TabStop = false;
            // 
            // pbxUitleg1
            // 
            this.pbxUitleg1.Image = global::JustinMunkEindopdrachtBommenGranaten.Properties.Resources.Coin;
            this.pbxUitleg1.Location = new System.Drawing.Point(435, 88);
            this.pbxUitleg1.Name = "pbxUitleg1";
            this.pbxUitleg1.Size = new System.Drawing.Size(151, 84);
            this.pbxUitleg1.TabIndex = 3;
            this.pbxUitleg1.TabStop = false;
            // 
            // pbxUitleg2
            // 
            this.pbxUitleg2.Image = global::JustinMunkEindopdrachtBommenGranaten.Properties.Resources.diamantWitte4;
            this.pbxUitleg2.Location = new System.Drawing.Point(435, 204);
            this.pbxUitleg2.Name = "pbxUitleg2";
            this.pbxUitleg2.Size = new System.Drawing.Size(151, 84);
            this.pbxUitleg2.TabIndex = 2;
            this.pbxUitleg2.TabStop = false;
            // 
            // pbxUitleg3
            // 
            this.pbxUitleg3.Image = global::JustinMunkEindopdrachtBommenGranaten.Properties.Resources.aap;
            this.pbxUitleg3.Location = new System.Drawing.Point(435, 314);
            this.pbxUitleg3.Name = "pbxUitleg3";
            this.pbxUitleg3.Size = new System.Drawing.Size(151, 84);
            this.pbxUitleg3.TabIndex = 1;
            this.pbxUitleg3.TabStop = false;
            // 
            // lblUitleg
            // 
            this.lblUitleg.AutoSize = true;
            this.lblUitleg.Font = new System.Drawing.Font("Trebuchet MS", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUitleg.Location = new System.Drawing.Point(697, 15);
            this.lblUitleg.Name = "lblUitleg";
            this.lblUitleg.Size = new System.Drawing.Size(236, 54);
            this.lblUitleg.TabIndex = 0;
            this.lblUitleg.Text = "speluitleg:";
            // 
            // lblScoreErbij
            // 
            this.lblScoreErbij.AutoSize = true;
            this.lblScoreErbij.Font = new System.Drawing.Font("MV Boli", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScoreErbij.Location = new System.Drawing.Point(1132, 314);
            this.lblScoreErbij.Name = "lblScoreErbij";
            this.lblScoreErbij.Size = new System.Drawing.Size(0, 37);
            this.lblScoreErbij.TabIndex = 26;
            // 
            // pbxTutorial
            // 
            this.pbxTutorial.Image = global::JustinMunkEindopdrachtBommenGranaten.Properties.Resources.Vraagteken;
            this.pbxTutorial.Location = new System.Drawing.Point(12, 334);
            this.pbxTutorial.Name = "pbxTutorial";
            this.pbxTutorial.Size = new System.Drawing.Size(143, 104);
            this.pbxTutorial.TabIndex = 24;
            this.pbxTutorial.TabStop = false;
            this.pbxTutorial.Click += new System.EventHandler(this.pbxTutorial_Click);
            // 
            // pbxDobbel5
            // 
            this.pbxDobbel5.BackColor = System.Drawing.Color.Transparent;
            this.pbxDobbel5.Image = global::JustinMunkEindopdrachtBommenGranaten.Properties.Resources.Letter_E_transparent;
            this.pbxDobbel5.Location = new System.Drawing.Point(699, 106);
            this.pbxDobbel5.Name = "pbxDobbel5";
            this.pbxDobbel5.Size = new System.Drawing.Size(154, 123);
            this.pbxDobbel5.TabIndex = 20;
            this.pbxDobbel5.TabStop = false;
            // 
            // pbxDobbel2
            // 
            this.pbxDobbel2.BackColor = System.Drawing.Color.Transparent;
            this.pbxDobbel2.Image = global::JustinMunkEindopdrachtBommenGranaten.Properties.Resources.Letter_O_Transparent;
            this.pbxDobbel2.Location = new System.Drawing.Point(197, 106);
            this.pbxDobbel2.Name = "pbxDobbel2";
            this.pbxDobbel2.Size = new System.Drawing.Size(154, 123);
            this.pbxDobbel2.TabIndex = 19;
            this.pbxDobbel2.TabStop = false;
            // 
            // pbxDobbel3
            // 
            this.pbxDobbel3.Image = global::JustinMunkEindopdrachtBommenGranaten.Properties.Resources.Letter_B_Transparent;
            this.pbxDobbel3.Location = new System.Drawing.Point(374, 106);
            this.pbxDobbel3.Name = "pbxDobbel3";
            this.pbxDobbel3.Size = new System.Drawing.Size(154, 123);
            this.pbxDobbel3.TabIndex = 18;
            this.pbxDobbel3.TabStop = false;
            // 
            // pbxDobbel4
            // 
            this.pbxDobbel4.Image = global::JustinMunkEindopdrachtBommenGranaten.Properties.Resources.Letter_B_Transparent;
            this.pbxDobbel4.Location = new System.Drawing.Point(534, 106);
            this.pbxDobbel4.Name = "pbxDobbel4";
            this.pbxDobbel4.Size = new System.Drawing.Size(154, 123);
            this.pbxDobbel4.TabIndex = 17;
            this.pbxDobbel4.TabStop = false;
            // 
            // pbxDobbel8
            // 
            this.pbxDobbel8.BackColor = System.Drawing.Color.Transparent;
            this.pbxDobbel8.Image = global::JustinMunkEindopdrachtBommenGranaten.Properties.Resources.Letter_N_Transparent;
            this.pbxDobbel8.Location = new System.Drawing.Point(1224, 106);
            this.pbxDobbel8.Name = "pbxDobbel8";
            this.pbxDobbel8.Size = new System.Drawing.Size(154, 123);
            this.pbxDobbel8.TabIndex = 16;
            this.pbxDobbel8.TabStop = false;
            // 
            // pbxDobbel7
            // 
            this.pbxDobbel7.BackColor = System.Drawing.Color.Transparent;
            this.pbxDobbel7.Image = global::JustinMunkEindopdrachtBommenGranaten.Properties.Resources.Letter_E_transparent;
            this.pbxDobbel7.Location = new System.Drawing.Point(1046, 106);
            this.pbxDobbel7.Name = "pbxDobbel7";
            this.pbxDobbel7.Size = new System.Drawing.Size(154, 123);
            this.pbxDobbel7.TabIndex = 15;
            this.pbxDobbel7.TabStop = false;
            // 
            // pbxDobbel6
            // 
            this.pbxDobbel6.BackColor = System.Drawing.Color.Transparent;
            this.pbxDobbel6.Image = global::JustinMunkEindopdrachtBommenGranaten.Properties.Resources.Letter_L_Transparent;
            this.pbxDobbel6.Location = new System.Drawing.Point(870, 106);
            this.pbxDobbel6.Name = "pbxDobbel6";
            this.pbxDobbel6.Size = new System.Drawing.Size(154, 123);
            this.pbxDobbel6.TabIndex = 14;
            this.pbxDobbel6.TabStop = false;
            // 
            // pbxDobbel1
            // 
            this.pbxDobbel1.BackColor = System.Drawing.Color.Transparent;
            this.pbxDobbel1.Image = global::JustinMunkEindopdrachtBommenGranaten.Properties.Resources.Letter_D_Transparant;
            this.pbxDobbel1.Location = new System.Drawing.Point(26, 106);
            this.pbxDobbel1.Name = "pbxDobbel1";
            this.pbxDobbel1.Size = new System.Drawing.Size(154, 123);
            this.pbxDobbel1.TabIndex = 13;
            this.pbxDobbel1.TabStop = false;
            // 
            // pbxBackground
            // 
            this.pbxBackground.Image = global::JustinMunkEindopdrachtBommenGranaten.Properties.Resources.background2_2;
            this.pbxBackground.Location = new System.Drawing.Point(0, 1);
            this.pbxBackground.Name = "pbxBackground";
            this.pbxBackground.Size = new System.Drawing.Size(1426, 449);
            this.pbxBackground.TabIndex = 27;
            this.pbxBackground.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cyan;
            this.ClientSize = new System.Drawing.Size(1425, 450);
            this.Controls.Add(this.lblScoreErbij);
            this.Controls.Add(this.pnlTutorial);
            this.Controls.Add(this.pbxTutorial);
            this.Controls.Add(this.lblScoreGetal);
            this.Controls.Add(this.lblScore);
            this.Controls.Add(this.btnGooi);
            this.Controls.Add(this.pbxDobbel5);
            this.Controls.Add(this.pbxDobbel2);
            this.Controls.Add(this.pbxDobbel3);
            this.Controls.Add(this.pbxDobbel4);
            this.Controls.Add(this.pbxDobbel8);
            this.Controls.Add(this.pbxDobbel7);
            this.Controls.Add(this.pbxDobbel6);
            this.Controls.Add(this.pbxDobbel1);
            this.Controls.Add(this.lblDobbel2);
            this.Controls.Add(this.lblDobbel3);
            this.Controls.Add(this.lblDobbel4);
            this.Controls.Add(this.lblDobbel5);
            this.Controls.Add(this.lblDobbel6);
            this.Controls.Add(this.lblDobbel7);
            this.Controls.Add(this.lblDobbel8);
            this.Controls.Add(this.lblDobbel1);
            this.Controls.Add(this.pbxBackground);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.pnlTutorial.ResumeLayout(false);
            this.pnlTutorial.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxTutorial2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxUitleg5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxUitleg6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxUitleg4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxUitleg1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxUitleg2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxUitleg3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxTutorial)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDobbel5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDobbel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDobbel3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDobbel4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDobbel8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDobbel7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDobbel6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDobbel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxBackground)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblDobbel1;
        private System.Windows.Forms.Label lblDobbel8;
        private System.Windows.Forms.Label lblDobbel7;
        private System.Windows.Forms.Label lblDobbel6;
        private System.Windows.Forms.Label lblDobbel5;
        private System.Windows.Forms.Label lblDobbel4;
        private System.Windows.Forms.Label lblDobbel3;
        private System.Windows.Forms.Label lblDobbel2;
        private System.Windows.Forms.PictureBox pbxDobbel1;
        private System.Windows.Forms.PictureBox pbxDobbel6;
        private System.Windows.Forms.PictureBox pbxDobbel7;
        private System.Windows.Forms.PictureBox pbxDobbel8;
        private System.Windows.Forms.PictureBox pbxDobbel4;
        private System.Windows.Forms.PictureBox pbxDobbel3;
        private System.Windows.Forms.PictureBox pbxDobbel2;
        private System.Windows.Forms.PictureBox pbxDobbel5;
        private System.Windows.Forms.Button btnGooi;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.Label lblScoreGetal;
        private System.Windows.Forms.PictureBox pbxTutorial;
        private System.Windows.Forms.Panel pnlTutorial;
        private System.Windows.Forms.Label lblUitleg;
        private System.Windows.Forms.PictureBox pbxUitleg3;
        private System.Windows.Forms.PictureBox pbxTutorial2;
        private System.Windows.Forms.PictureBox pbxUitleg5;
        private System.Windows.Forms.PictureBox pbxUitleg6;
        private System.Windows.Forms.PictureBox pbxUitleg4;
        private System.Windows.Forms.PictureBox pbxUitleg1;
        private System.Windows.Forms.PictureBox pbxUitleg2;
        private System.Windows.Forms.Label lblUitleg1;
        private System.Windows.Forms.Label lblUitlegMunt;
        private System.Windows.Forms.Label lblUitlegLichtZwaard;
        private System.Windows.Forms.Label lblUitlegCockatoo;
        private System.Windows.Forms.Label lblUitlegAap;
        private System.Windows.Forms.Label lblUitlegDiamant;
        private System.Windows.Forms.Label lblUitlegSchedel;
        private System.Windows.Forms.Label lbl0Punten;
        private System.Windows.Forms.Label lblScoreErbij;
        private System.Windows.Forms.PictureBox pbxBackground;
    }
}

