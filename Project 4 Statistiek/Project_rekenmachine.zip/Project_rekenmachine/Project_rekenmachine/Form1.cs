﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_rekenmachine
{
    public partial class Form1 : Form
    {
        double uitkomstGetal = 0;
        public Form1()
        {
            InitializeComponent();
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {
          
        }

        private void txtGetal1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnPlus_Click(object sender, EventArgs e)
        {
            calculate("plus");
        }

        private void btnMin_Click(object sender, EventArgs e)
        {
            calculate("min");
        }

        private void btnMaal_Click(object sender, EventArgs e)
        {
            calculate("maal");
        }

        private void btnGedeeldDoor_Click(object sender, EventArgs e)
        {
            calculate("gedeeld door");
        }

        private void btnUitkomst_Click(object sender, EventArgs e)
        {
                txtUitkomst.Text = uitkomstGetal.ToString();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pnlbtnBasis_Click(object sender, EventArgs e)
        {
            pnlScience.Visible = false;
        }

        private void btnScience_Click(object sender, EventArgs e)
        {
            pnlScience.Visible = true;
        }

        private void pnlbtnUitkomst_Click(object sender, EventArgs e)
        {
            pnltxtUitkomst.Text = uitkomstGetal.ToString();
        }

        private void pnlbtnSinus_Click(object sender, EventArgs e)
        {
            calculate("sinus");
        }

        private void pnlbtnCosinus_Click(object sender, EventArgs e)
        {
            calculate("cosinus");
        }

        private void pnlbtnKwadraad_Click(object sender, EventArgs e)
        {
            calculate("kwadraad");
        }

        private void pnlbtnWortel_Click(object sender, EventArgs e)
        {
            calculate("wortel");
        }

        private void calculate(string type)
        {
            double value1;
            double value2 = 0;

            if (pnlScience.Visible)
            {
                if (!double.TryParse(pnltxtGetal1.Text, out value1))
                {
                    MessageBox.Show("Niet geldig");
                    return;
                }
                if (type != "sinus" && type != "cosinus" && type != "wortel")
               {
                    if (!double.TryParse(pnltxtGetal2.Text, out value2))
                    {
                        MessageBox.Show("Niet geldig");
                        return;
                    }
                }
            }
            else
            {
                if (!double.TryParse(txtGetal1.Text, out value1))
                {
                    MessageBox.Show("Niet geldig");
                    return;
                }
                if (!double.TryParse(txtGetal2.Text, out value2))
                {
                    MessageBox.Show("Niet geldig");
                    return;
                }
            }
         
            switch (type)
            {
                case "min":
                    uitkomstGetal = value1 - value2;
                    break;
                case "plus":
                    uitkomstGetal = value1 + value2;
                    break;
                case "maal":
                    uitkomstGetal = value1 * value2;
                    break;
                case "gedeeld door":
                    uitkomstGetal = value1 / value2;
                    break;
                case "sinus":
                    double angleDegreesSin = double.Parse(pnltxtGetal1.Text);
                    double angleRadiansSin = Math.PI * angleDegreesSin / 180;
                    double sin = Math.Sin(angleRadiansSin);
                    uitkomstGetal = sin;
                    break;
                case "cosinus":
                    double angleDegreesCos = double.Parse(pnltxtGetal1.Text);
                    double angleRadiansCos = Math.PI * angleDegreesCos / 180;
                    double cos = Math.Cos(angleRadiansCos);
                    uitkomstGetal = cos;
                    break;
                case "kwadraad":
                    uitkomstGetal=Math.Pow(double.Parse(pnltxtGetal1.Text), double.Parse(pnltxtGetal2.Text));
                    break;
                case "wortel":
                   uitkomstGetal=Math.Sqrt(double.Parse(pnltxtGetal1.Text));
                        break;

            }

  
        }
    }
}
