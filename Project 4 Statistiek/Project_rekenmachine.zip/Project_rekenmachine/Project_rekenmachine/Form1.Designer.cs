﻿namespace Project_rekenmachine
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnUitkomst = new System.Windows.Forms.Button();
            this.btnScience = new System.Windows.Forms.Button();
            this.btnBasis = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnMaal = new System.Windows.Forms.Button();
            this.btnGedeeldDoor = new System.Windows.Forms.Button();
            this.btnMin = new System.Windows.Forms.Button();
            this.btnPlus = new System.Windows.Forms.Button();
            this.txtUitkomst = new System.Windows.Forms.TextBox();
            this.txtGetal2 = new System.Windows.Forms.TextBox();
            this.txtGetal1 = new System.Windows.Forms.TextBox();
            this.pnlScience = new System.Windows.Forms.Panel();
            this.pnltxtUitkomst = new System.Windows.Forms.TextBox();
            this.pnltxtGetal2 = new System.Windows.Forms.TextBox();
            this.pnltxtGetal1 = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pnlbtnUitkomst = new System.Windows.Forms.Button();
            this.pnlbtnKwadraad = new System.Windows.Forms.Button();
            this.pnlbtnWortel = new System.Windows.Forms.Button();
            this.pnlbtnCosinus = new System.Windows.Forms.Button();
            this.pnlbtnSinus = new System.Windows.Forms.Button();
            this.pnlbtnScience = new System.Windows.Forms.Button();
            this.pnlbtnBasis = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnlScience.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // btnUitkomst
            // 
            this.btnUitkomst.BackColor = System.Drawing.Color.DeepPink;
            this.btnUitkomst.Font = new System.Drawing.Font("Comic Sans MS", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUitkomst.Location = new System.Drawing.Point(253, 309);
            this.btnUitkomst.Name = "btnUitkomst";
            this.btnUitkomst.Size = new System.Drawing.Size(57, 46);
            this.btnUitkomst.TabIndex = 7;
            this.btnUitkomst.Text = "=";
            this.btnUitkomst.UseVisualStyleBackColor = false;
            this.btnUitkomst.Click += new System.EventHandler(this.btnUitkomst_Click);
            // 
            // btnScience
            // 
            this.btnScience.BackColor = System.Drawing.Color.DeepPink;
            this.btnScience.Font = new System.Drawing.Font("Comic Sans MS", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnScience.Location = new System.Drawing.Point(113, 306);
            this.btnScience.Name = "btnScience";
            this.btnScience.Size = new System.Drawing.Size(96, 46);
            this.btnScience.TabIndex = 10;
            this.btnScience.Text = "Science";
            this.btnScience.UseVisualStyleBackColor = false;
            this.btnScience.Click += new System.EventHandler(this.btnScience_Click);
            // 
            // btnBasis
            // 
            this.btnBasis.BackColor = System.Drawing.Color.DeepPink;
            this.btnBasis.Font = new System.Drawing.Font("Comic Sans MS", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBasis.Location = new System.Drawing.Point(-5, 304);
            this.btnBasis.Name = "btnBasis";
            this.btnBasis.Size = new System.Drawing.Size(95, 51);
            this.btnBasis.TabIndex = 9;
            this.btnBasis.Text = "basis";
            this.btnBasis.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-5, -131);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(315, 248);
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // btnMaal
            // 
            this.btnMaal.BackColor = System.Drawing.Color.DeepPink;
            this.btnMaal.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMaal.Location = new System.Drawing.Point(68, 233);
            this.btnMaal.Name = "btnMaal";
            this.btnMaal.Size = new System.Drawing.Size(57, 46);
            this.btnMaal.TabIndex = 5;
            this.btnMaal.Text = "X";
            this.btnMaal.UseVisualStyleBackColor = false;
            this.btnMaal.Click += new System.EventHandler(this.btnMaal_Click);
            // 
            // btnGedeeldDoor
            // 
            this.btnGedeeldDoor.BackColor = System.Drawing.Color.DeepPink;
            this.btnGedeeldDoor.Font = new System.Drawing.Font("Comic Sans MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGedeeldDoor.Location = new System.Drawing.Point(178, 233);
            this.btnGedeeldDoor.Name = "btnGedeeldDoor";
            this.btnGedeeldDoor.Size = new System.Drawing.Size(57, 46);
            this.btnGedeeldDoor.TabIndex = 3;
            this.btnGedeeldDoor.Text = "/";
            this.btnGedeeldDoor.UseVisualStyleBackColor = false;
            this.btnGedeeldDoor.Click += new System.EventHandler(this.btnGedeeldDoor_Click);
            // 
            // btnMin
            // 
            this.btnMin.BackColor = System.Drawing.Color.DeepPink;
            this.btnMin.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMin.Location = new System.Drawing.Point(178, 169);
            this.btnMin.Name = "btnMin";
            this.btnMin.Size = new System.Drawing.Size(57, 46);
            this.btnMin.TabIndex = 4;
            this.btnMin.Text = "-";
            this.btnMin.UseVisualStyleBackColor = false;
            this.btnMin.Click += new System.EventHandler(this.btnMin_Click);
            // 
            // btnPlus
            // 
            this.btnPlus.BackColor = System.Drawing.Color.DeepPink;
            this.btnPlus.Font = new System.Drawing.Font("Comic Sans MS", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlus.Location = new System.Drawing.Point(68, 169);
            this.btnPlus.Name = "btnPlus";
            this.btnPlus.Size = new System.Drawing.Size(57, 46);
            this.btnPlus.TabIndex = 2;
            this.btnPlus.Text = "+";
            this.btnPlus.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnPlus.UseVisualStyleBackColor = false;
            this.btnPlus.Click += new System.EventHandler(this.btnPlus_Click);
            // 
            // txtUitkomst
            // 
            this.txtUitkomst.Location = new System.Drawing.Point(30, 123);
            this.txtUitkomst.Name = "txtUitkomst";
            this.txtUitkomst.ReadOnly = true;
            this.txtUitkomst.Size = new System.Drawing.Size(245, 22);
            this.txtUitkomst.TabIndex = 6;
            this.txtUitkomst.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtGetal2
            // 
            this.txtGetal2.Location = new System.Drawing.Point(68, 75);
            this.txtGetal2.Name = "txtGetal2";
            this.txtGetal2.Size = new System.Drawing.Size(167, 22);
            this.txtGetal2.TabIndex = 1;
            this.txtGetal2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtGetal1
            // 
            this.txtGetal1.Location = new System.Drawing.Point(68, 26);
            this.txtGetal1.Name = "txtGetal1";
            this.txtGetal1.Size = new System.Drawing.Size(167, 22);
            this.txtGetal1.TabIndex = 0;
            this.txtGetal1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtGetal1.TextChanged += new System.EventHandler(this.txtGetal1_TextChanged);
            // 
            // pnlScience
            // 
            this.pnlScience.Controls.Add(this.pnltxtUitkomst);
            this.pnlScience.Controls.Add(this.pnltxtGetal2);
            this.pnlScience.Controls.Add(this.pnltxtGetal1);
            this.pnlScience.Controls.Add(this.pictureBox2);
            this.pnlScience.Controls.Add(this.pnlbtnUitkomst);
            this.pnlScience.Controls.Add(this.pnlbtnKwadraad);
            this.pnlScience.Controls.Add(this.pnlbtnWortel);
            this.pnlScience.Controls.Add(this.pnlbtnCosinus);
            this.pnlScience.Controls.Add(this.pnlbtnSinus);
            this.pnlScience.Controls.Add(this.pnlbtnScience);
            this.pnlScience.Controls.Add(this.pnlbtnBasis);
            this.pnlScience.Location = new System.Drawing.Point(-5, -2);
            this.pnlScience.Name = "pnlScience";
            this.pnlScience.Size = new System.Drawing.Size(315, 357);
            this.pnlScience.TabIndex = 11;
            // 
            // pnltxtUitkomst
            // 
            this.pnltxtUitkomst.Location = new System.Drawing.Point(30, 125);
            this.pnltxtUitkomst.Name = "pnltxtUitkomst";
            this.pnltxtUitkomst.ReadOnly = true;
            this.pnltxtUitkomst.Size = new System.Drawing.Size(245, 22);
            this.pnltxtUitkomst.TabIndex = 12;
            this.pnltxtUitkomst.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pnltxtGetal2
            // 
            this.pnltxtGetal2.Location = new System.Drawing.Point(73, 77);
            this.pnltxtGetal2.Name = "pnltxtGetal2";
            this.pnltxtGetal2.Size = new System.Drawing.Size(167, 22);
            this.pnltxtGetal2.TabIndex = 12;
            this.pnltxtGetal2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // pnltxtGetal1
            // 
            this.pnltxtGetal1.Location = new System.Drawing.Point(73, 28);
            this.pnltxtGetal1.Name = "pnltxtGetal1";
            this.pnltxtGetal1.Size = new System.Drawing.Size(167, 22);
            this.pnltxtGetal1.TabIndex = 12;
            this.pnltxtGetal1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(-58, -129);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(370, 238);
            this.pictureBox2.TabIndex = 13;
            this.pictureBox2.TabStop = false;
            // 
            // pnlbtnUitkomst
            // 
            this.pnlbtnUitkomst.BackColor = System.Drawing.Color.DarkOrange;
            this.pnlbtnUitkomst.Font = new System.Drawing.Font("Comic Sans MS", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlbtnUitkomst.Location = new System.Drawing.Point(258, 311);
            this.pnlbtnUitkomst.Name = "pnlbtnUitkomst";
            this.pnlbtnUitkomst.Size = new System.Drawing.Size(57, 46);
            this.pnlbtnUitkomst.TabIndex = 12;
            this.pnlbtnUitkomst.Text = "=";
            this.pnlbtnUitkomst.UseVisualStyleBackColor = false;
            this.pnlbtnUitkomst.Click += new System.EventHandler(this.pnlbtnUitkomst_Click);
            // 
            // pnlbtnKwadraad
            // 
            this.pnlbtnKwadraad.BackColor = System.Drawing.Color.DarkOrange;
            this.pnlbtnKwadraad.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlbtnKwadraad.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.pnlbtnKwadraad.Location = new System.Drawing.Point(73, 171);
            this.pnlbtnKwadraad.Name = "pnlbtnKwadraad";
            this.pnlbtnKwadraad.Size = new System.Drawing.Size(57, 46);
            this.pnlbtnKwadraad.TabIndex = 5;
            this.pnlbtnKwadraad.Text = "^";
            this.pnlbtnKwadraad.UseVisualStyleBackColor = false;
            this.pnlbtnKwadraad.Click += new System.EventHandler(this.pnlbtnKwadraad_Click);
            // 
            // pnlbtnWortel
            // 
            this.pnlbtnWortel.BackColor = System.Drawing.Color.DarkOrange;
            this.pnlbtnWortel.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlbtnWortel.Location = new System.Drawing.Point(181, 171);
            this.pnlbtnWortel.Name = "pnlbtnWortel";
            this.pnlbtnWortel.Size = new System.Drawing.Size(57, 46);
            this.pnlbtnWortel.TabIndex = 4;
            this.pnlbtnWortel.Text = "√";
            this.pnlbtnWortel.UseVisualStyleBackColor = false;
            this.pnlbtnWortel.Click += new System.EventHandler(this.pnlbtnWortel_Click);
            // 
            // pnlbtnCosinus
            // 
            this.pnlbtnCosinus.BackColor = System.Drawing.Color.DarkOrange;
            this.pnlbtnCosinus.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlbtnCosinus.Location = new System.Drawing.Point(181, 235);
            this.pnlbtnCosinus.Name = "pnlbtnCosinus";
            this.pnlbtnCosinus.Size = new System.Drawing.Size(57, 46);
            this.pnlbtnCosinus.TabIndex = 3;
            this.pnlbtnCosinus.Text = "COS";
            this.pnlbtnCosinus.UseVisualStyleBackColor = false;
            this.pnlbtnCosinus.Click += new System.EventHandler(this.pnlbtnCosinus_Click);
            // 
            // pnlbtnSinus
            // 
            this.pnlbtnSinus.BackColor = System.Drawing.Color.DarkOrange;
            this.pnlbtnSinus.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlbtnSinus.Location = new System.Drawing.Point(73, 235);
            this.pnlbtnSinus.Name = "pnlbtnSinus";
            this.pnlbtnSinus.Size = new System.Drawing.Size(57, 46);
            this.pnlbtnSinus.TabIndex = 2;
            this.pnlbtnSinus.Text = "SIN";
            this.pnlbtnSinus.UseVisualStyleBackColor = false;
            this.pnlbtnSinus.Click += new System.EventHandler(this.pnlbtnSinus_Click);
            // 
            // pnlbtnScience
            // 
            this.pnlbtnScience.BackColor = System.Drawing.Color.DarkOrange;
            this.pnlbtnScience.Font = new System.Drawing.Font("Comic Sans MS", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlbtnScience.Location = new System.Drawing.Point(122, 311);
            this.pnlbtnScience.Name = "pnlbtnScience";
            this.pnlbtnScience.Size = new System.Drawing.Size(92, 46);
            this.pnlbtnScience.TabIndex = 1;
            this.pnlbtnScience.Text = "Science";
            this.pnlbtnScience.UseVisualStyleBackColor = false;
            // 
            // pnlbtnBasis
            // 
            this.pnlbtnBasis.BackColor = System.Drawing.Color.DarkOrange;
            this.pnlbtnBasis.Font = new System.Drawing.Font("Comic Sans MS", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlbtnBasis.Location = new System.Drawing.Point(3, 311);
            this.pnlbtnBasis.Name = "pnlbtnBasis";
            this.pnlbtnBasis.Size = new System.Drawing.Size(92, 46);
            this.pnlbtnBasis.TabIndex = 0;
            this.pnlbtnBasis.Text = "basis";
            this.pnlbtnBasis.UseVisualStyleBackColor = false;
            this.pnlbtnBasis.Click += new System.EventHandler(this.pnlbtnBasis_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(308, 353);
            this.Controls.Add(this.pnlScience);
            this.Controls.Add(this.btnBasis);
            this.Controls.Add(this.btnMaal);
            this.Controls.Add(this.btnScience);
            this.Controls.Add(this.btnGedeeldDoor);
            this.Controls.Add(this.btnUitkomst);
            this.Controls.Add(this.btnPlus);
            this.Controls.Add(this.txtUitkomst);
            this.Controls.Add(this.btnMin);
            this.Controls.Add(this.txtGetal2);
            this.Controls.Add(this.txtGetal1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Rekenmachine";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnlScience.ResumeLayout(false);
            this.pnlScience.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnUitkomst;
        private System.Windows.Forms.Button btnScience;
        private System.Windows.Forms.Button btnBasis;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnMaal;
        private System.Windows.Forms.Button btnGedeeldDoor;
        private System.Windows.Forms.Button btnMin;
        private System.Windows.Forms.Button btnPlus;
        private System.Windows.Forms.TextBox txtUitkomst;
        private System.Windows.Forms.TextBox txtGetal2;
        private System.Windows.Forms.TextBox txtGetal1;
        private System.Windows.Forms.Panel pnlScience;
        private System.Windows.Forms.Button pnlbtnKwadraad;
        private System.Windows.Forms.Button pnlbtnWortel;
        private System.Windows.Forms.Button pnlbtnCosinus;
        private System.Windows.Forms.Button pnlbtnSinus;
        private System.Windows.Forms.Button pnlbtnScience;
        private System.Windows.Forms.Button pnlbtnBasis;
        private System.Windows.Forms.Button pnlbtnUitkomst;
        private System.Windows.Forms.TextBox pnltxtUitkomst;
        private System.Windows.Forms.TextBox pnltxtGetal2;
        private System.Windows.Forms.TextBox pnltxtGetal1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}

