﻿namespace WhileLusOpdracht6
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lblVan = new System.Windows.Forms.Label();
            this.lblTot = new System.Windows.Forms.Label();
            this.chkTotEnMet = new System.Windows.Forms.CheckBox();
            this.txtVan = new System.Windows.Forms.TextBox();
            this.txtTot = new System.Windows.Forms.TextBox();
            this.lbxCijfers = new System.Windows.Forms.ListBox();
            this.lblGemiddelde = new System.Windows.Forms.Label();
            this.lblTotaal = new System.Windows.Forms.Label();
            this.btnGeefStatistiek = new System.Windows.Forms.Button();
            this.btnWis = new System.Windows.Forms.Button();
            this.txtGemiddelde = new System.Windows.Forms.TextBox();
            this.txtTotaal = new System.Windows.Forms.TextBox();
            this.lblWhileLus6 = new System.Windows.Forms.Label();
            this.pbxEmoji = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbxEmoji)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblVan
            // 
            this.lblVan.AutoSize = true;
            this.lblVan.Location = new System.Drawing.Point(65, 180);
            this.lblVan.Name = "lblVan";
            this.lblVan.Size = new System.Drawing.Size(34, 16);
            this.lblVan.TabIndex = 0;
            this.lblVan.Text = "Van:";
            // 
            // lblTot
            // 
            this.lblTot.AutoSize = true;
            this.lblTot.Location = new System.Drawing.Point(69, 239);
            this.lblTot.Name = "lblTot";
            this.lblTot.Size = new System.Drawing.Size(30, 16);
            this.lblTot.TabIndex = 1;
            this.lblTot.Text = "Tot:";
            // 
            // chkTotEnMet
            // 
            this.chkTotEnMet.AutoSize = true;
            this.chkTotEnMet.Location = new System.Drawing.Point(86, 292);
            this.chkTotEnMet.Name = "chkTotEnMet";
            this.chkTotEnMet.Size = new System.Drawing.Size(99, 20);
            this.chkTotEnMet.TabIndex = 2;
            this.chkTotEnMet.Text = "Tot en Met?";
            this.chkTotEnMet.UseVisualStyleBackColor = true;
            // 
            // txtVan
            // 
            this.txtVan.Location = new System.Drawing.Point(122, 177);
            this.txtVan.Name = "txtVan";
            this.txtVan.Size = new System.Drawing.Size(129, 22);
            this.txtVan.TabIndex = 3;
            // 
            // txtTot
            // 
            this.txtTot.Location = new System.Drawing.Point(122, 233);
            this.txtTot.Name = "txtTot";
            this.txtTot.Size = new System.Drawing.Size(129, 22);
            this.txtTot.TabIndex = 4;
            // 
            // lbxCijfers
            // 
            this.lbxCijfers.FormattingEnabled = true;
            this.lbxCijfers.ItemHeight = 16;
            this.lbxCijfers.Location = new System.Drawing.Point(311, 101);
            this.lbxCijfers.Name = "lbxCijfers";
            this.lbxCijfers.Size = new System.Drawing.Size(284, 340);
            this.lbxCijfers.TabIndex = 5;
            // 
            // lblGemiddelde
            // 
            this.lblGemiddelde.AutoSize = true;
            this.lblGemiddelde.Location = new System.Drawing.Point(338, 482);
            this.lblGemiddelde.Name = "lblGemiddelde";
            this.lblGemiddelde.Size = new System.Drawing.Size(85, 16);
            this.lblGemiddelde.TabIndex = 6;
            this.lblGemiddelde.Text = "Gemiddelde:";
            // 
            // lblTotaal
            // 
            this.lblTotaal.AutoSize = true;
            this.lblTotaal.Location = new System.Drawing.Point(338, 526);
            this.lblTotaal.Name = "lblTotaal";
            this.lblTotaal.Size = new System.Drawing.Size(46, 16);
            this.lblTotaal.TabIndex = 7;
            this.lblTotaal.Text = "Totaal";
            // 
            // btnGeefStatistiek
            // 
            this.btnGeefStatistiek.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGeefStatistiek.Location = new System.Drawing.Point(81, 330);
            this.btnGeefStatistiek.Name = "btnGeefStatistiek";
            this.btnGeefStatistiek.Size = new System.Drawing.Size(170, 80);
            this.btnGeefStatistiek.TabIndex = 8;
            this.btnGeefStatistiek.Text = "Geef Statistiek";
            this.btnGeefStatistiek.UseVisualStyleBackColor = true;
            this.btnGeefStatistiek.Click += new System.EventHandler(this.btnGeefStatistiek_Click);
            // 
            // btnWis
            // 
            this.btnWis.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWis.Location = new System.Drawing.Point(52, 432);
            this.btnWis.Name = "btnWis";
            this.btnWis.Size = new System.Drawing.Size(232, 166);
            this.btnWis.TabIndex = 9;
            this.btnWis.Text = "Wis";
            this.btnWis.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnWis.UseVisualStyleBackColor = true;
            this.btnWis.Click += new System.EventHandler(this.btnWis_Click);
            // 
            // txtGemiddelde
            // 
            this.txtGemiddelde.Location = new System.Drawing.Point(441, 479);
            this.txtGemiddelde.Name = "txtGemiddelde";
            this.txtGemiddelde.ReadOnly = true;
            this.txtGemiddelde.Size = new System.Drawing.Size(129, 22);
            this.txtGemiddelde.TabIndex = 10;
            // 
            // txtTotaal
            // 
            this.txtTotaal.Location = new System.Drawing.Point(441, 526);
            this.txtTotaal.Name = "txtTotaal";
            this.txtTotaal.ReadOnly = true;
            this.txtTotaal.Size = new System.Drawing.Size(129, 22);
            this.txtTotaal.TabIndex = 11;
            // 
            // lblWhileLus6
            // 
            this.lblWhileLus6.AutoSize = true;
            this.lblWhileLus6.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWhileLus6.ForeColor = System.Drawing.Color.Red;
            this.lblWhileLus6.Location = new System.Drawing.Point(720, 24);
            this.lblWhileLus6.Name = "lblWhileLus6";
            this.lblWhileLus6.Size = new System.Drawing.Size(249, 54);
            this.lblWhileLus6.TabIndex = 12;
            this.lblWhileLus6.Text = "While lus 6";
            // 
            // pbxEmoji
            // 
            this.pbxEmoji.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pbxEmoji.Image = ((System.Drawing.Image)(resources.GetObject("pbxEmoji.Image")));
            this.pbxEmoji.Location = new System.Drawing.Point(601, 81);
            this.pbxEmoji.Name = "pbxEmoji";
            this.pbxEmoji.Size = new System.Drawing.Size(622, 482);
            this.pbxEmoji.TabIndex = 13;
            this.pbxEmoji.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Gainsboro;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(132, 443);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(119, 154);
            this.pictureBox1.TabIndex = 14;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1069, 610);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pbxEmoji);
            this.Controls.Add(this.lblWhileLus6);
            this.Controls.Add(this.txtTotaal);
            this.Controls.Add(this.txtGemiddelde);
            this.Controls.Add(this.btnWis);
            this.Controls.Add(this.btnGeefStatistiek);
            this.Controls.Add(this.lblTotaal);
            this.Controls.Add(this.lblGemiddelde);
            this.Controls.Add(this.lbxCijfers);
            this.Controls.Add(this.txtTot);
            this.Controls.Add(this.txtVan);
            this.Controls.Add(this.chkTotEnMet);
            this.Controls.Add(this.lblTot);
            this.Controls.Add(this.lblVan);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pbxEmoji)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblVan;
        private System.Windows.Forms.Label lblTot;
        private System.Windows.Forms.CheckBox chkTotEnMet;
        private System.Windows.Forms.TextBox txtVan;
        private System.Windows.Forms.TextBox txtTot;
        private System.Windows.Forms.ListBox lbxCijfers;
        private System.Windows.Forms.Label lblGemiddelde;
        private System.Windows.Forms.Label lblTotaal;
        private System.Windows.Forms.Button btnGeefStatistiek;
        private System.Windows.Forms.Button btnWis;
        private System.Windows.Forms.TextBox txtGemiddelde;
        private System.Windows.Forms.TextBox txtTotaal;
        private System.Windows.Forms.Label lblWhileLus6;
        private System.Windows.Forms.PictureBox pbxEmoji;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

