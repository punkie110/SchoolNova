﻿namespace Justin_Munk_Opdracht6
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblForLus = new System.Windows.Forms.Label();
            this.lblCijfer = new System.Windows.Forms.Label();
            this.lblAantalKeer = new System.Windows.Forms.Label();
            this.lbxOutput = new System.Windows.Forms.ListBox();
            this.txtCijfer = new System.Windows.Forms.TextBox();
            this.txtAantalKeer = new System.Windows.Forms.TextBox();
            this.btnGeefStatistiek = new System.Windows.Forms.Button();
            this.btnBereken = new System.Windows.Forms.Button();
            this.btnWis = new System.Windows.Forms.Button();
            this.lblTotaal = new System.Windows.Forms.Label();
            this.lblGemiddelde = new System.Windows.Forms.Label();
            this.txtTotaal = new System.Windows.Forms.TextBox();
            this.txtGemiddelde = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblForLus
            // 
            this.lblForLus.AutoSize = true;
            this.lblForLus.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblForLus.ForeColor = System.Drawing.Color.Fuchsia;
            this.lblForLus.Location = new System.Drawing.Point(539, 63);
            this.lblForLus.Name = "lblForLus";
            this.lblForLus.Size = new System.Drawing.Size(145, 42);
            this.lblForLus.TabIndex = 0;
            this.lblForLus.Text = "For Lus";
            // 
            // lblCijfer
            // 
            this.lblCijfer.AutoSize = true;
            this.lblCijfer.Location = new System.Drawing.Point(95, 89);
            this.lblCijfer.Name = "lblCijfer";
            this.lblCijfer.Size = new System.Drawing.Size(40, 16);
            this.lblCijfer.TabIndex = 1;
            this.lblCijfer.Text = "Cijfer:";
            // 
            // lblAantalKeer
            // 
            this.lblAantalKeer.AutoSize = true;
            this.lblAantalKeer.Location = new System.Drawing.Point(56, 137);
            this.lblAantalKeer.Name = "lblAantalKeer";
            this.lblAantalKeer.Size = new System.Drawing.Size(79, 16);
            this.lblAantalKeer.TabIndex = 2;
            this.lblAantalKeer.Text = "Aantal Keer:";
            // 
            // lbxOutput
            // 
            this.lbxOutput.BackColor = System.Drawing.Color.Cyan;
            this.lbxOutput.FormattingEnabled = true;
            this.lbxOutput.ItemHeight = 16;
            this.lbxOutput.Location = new System.Drawing.Point(167, 176);
            this.lbxOutput.Name = "lbxOutput";
            this.lbxOutput.Size = new System.Drawing.Size(178, 196);
            this.lbxOutput.TabIndex = 3;
            // 
            // txtCijfer
            // 
            this.txtCijfer.Location = new System.Drawing.Point(182, 89);
            this.txtCijfer.Name = "txtCijfer";
            this.txtCijfer.Size = new System.Drawing.Size(142, 22);
            this.txtCijfer.TabIndex = 4;
            // 
            // txtAantalKeer
            // 
            this.txtAantalKeer.Location = new System.Drawing.Point(182, 137);
            this.txtAantalKeer.Name = "txtAantalKeer";
            this.txtAantalKeer.Size = new System.Drawing.Size(142, 22);
            this.txtAantalKeer.TabIndex = 5;
            // 
            // btnGeefStatistiek
            // 
            this.btnGeefStatistiek.BackColor = System.Drawing.Color.Aqua;
            this.btnGeefStatistiek.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGeefStatistiek.Location = new System.Drawing.Point(162, 378);
            this.btnGeefStatistiek.Name = "btnGeefStatistiek";
            this.btnGeefStatistiek.Size = new System.Drawing.Size(183, 73);
            this.btnGeefStatistiek.TabIndex = 6;
            this.btnGeefStatistiek.Text = "Geef Statistiek";
            this.btnGeefStatistiek.UseVisualStyleBackColor = false;
            this.btnGeefStatistiek.Click += new System.EventHandler(this.btnGeefStatistiek_Click);
            // 
            // btnBereken
            // 
            this.btnBereken.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnBereken.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBereken.Location = new System.Drawing.Point(360, 378);
            this.btnBereken.Name = "btnBereken";
            this.btnBereken.Size = new System.Drawing.Size(183, 73);
            this.btnBereken.TabIndex = 7;
            this.btnBereken.Text = "Bereken";
            this.btnBereken.UseVisualStyleBackColor = false;
            this.btnBereken.Click += new System.EventHandler(this.btnBereken_Click);
            // 
            // btnWis
            // 
            this.btnWis.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnWis.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWis.Location = new System.Drawing.Point(567, 378);
            this.btnWis.Name = "btnWis";
            this.btnWis.Size = new System.Drawing.Size(183, 73);
            this.btnWis.TabIndex = 8;
            this.btnWis.Text = "Wis";
            this.btnWis.UseVisualStyleBackColor = false;
            this.btnWis.Click += new System.EventHandler(this.btnWis_Click);
            // 
            // lblTotaal
            // 
            this.lblTotaal.AutoSize = true;
            this.lblTotaal.Location = new System.Drawing.Point(391, 237);
            this.lblTotaal.Name = "lblTotaal";
            this.lblTotaal.Size = new System.Drawing.Size(49, 16);
            this.lblTotaal.TabIndex = 9;
            this.lblTotaal.Text = "Totaal:";
            // 
            // lblGemiddelde
            // 
            this.lblGemiddelde.AutoSize = true;
            this.lblGemiddelde.Location = new System.Drawing.Point(391, 315);
            this.lblGemiddelde.Name = "lblGemiddelde";
            this.lblGemiddelde.Size = new System.Drawing.Size(85, 16);
            this.lblGemiddelde.TabIndex = 10;
            this.lblGemiddelde.Text = "Gemiddelde:";
            // 
            // txtTotaal
            // 
            this.txtTotaal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.txtTotaal.Location = new System.Drawing.Point(394, 273);
            this.txtTotaal.Name = "txtTotaal";
            this.txtTotaal.ReadOnly = true;
            this.txtTotaal.Size = new System.Drawing.Size(138, 22);
            this.txtTotaal.TabIndex = 11;
            // 
            // txtGemiddelde
            // 
            this.txtGemiddelde.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.txtGemiddelde.Location = new System.Drawing.Point(394, 350);
            this.txtGemiddelde.Name = "txtGemiddelde";
            this.txtGemiddelde.ReadOnly = true;
            this.txtGemiddelde.Size = new System.Drawing.Size(138, 22);
            this.txtGemiddelde.TabIndex = 12;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtGemiddelde);
            this.Controls.Add(this.txtTotaal);
            this.Controls.Add(this.lblGemiddelde);
            this.Controls.Add(this.lblTotaal);
            this.Controls.Add(this.btnWis);
            this.Controls.Add(this.btnBereken);
            this.Controls.Add(this.btnGeefStatistiek);
            this.Controls.Add(this.txtAantalKeer);
            this.Controls.Add(this.txtCijfer);
            this.Controls.Add(this.lbxOutput);
            this.Controls.Add(this.lblAantalKeer);
            this.Controls.Add(this.lblCijfer);
            this.Controls.Add(this.lblForLus);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblForLus;
        private System.Windows.Forms.Label lblCijfer;
        private System.Windows.Forms.Label lblAantalKeer;
        private System.Windows.Forms.ListBox lbxOutput;
        private System.Windows.Forms.TextBox txtCijfer;
        private System.Windows.Forms.TextBox txtAantalKeer;
        private System.Windows.Forms.Button btnGeefStatistiek;
        private System.Windows.Forms.Button btnBereken;
        private System.Windows.Forms.Button btnWis;
        private System.Windows.Forms.Label lblTotaal;
        private System.Windows.Forms.Label lblGemiddelde;
        private System.Windows.Forms.TextBox txtTotaal;
        private System.Windows.Forms.TextBox txtGemiddelde;
    }
}

