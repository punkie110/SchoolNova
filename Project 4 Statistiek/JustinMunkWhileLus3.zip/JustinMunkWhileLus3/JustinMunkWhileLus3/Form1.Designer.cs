﻿namespace JustinMunkWhileLus3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblWhileLus3 = new System.Windows.Forms.Label();
            this.lbxEenTotTien = new System.Windows.Forms.ListBox();
            this.lbxNegentigTotHonderd = new System.Windows.Forms.ListBox();
            this.lbxHonderdTotNegentig = new System.Windows.Forms.ListBox();
            this.btnStatistiek1Tot10 = new System.Windows.Forms.Button();
            this.btnStatistiek90Tot100 = new System.Windows.Forms.Button();
            this.btnStatistiek100Tot90 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblWhileLus3
            // 
            this.lblWhileLus3.AutoSize = true;
            this.lblWhileLus3.BackColor = System.Drawing.Color.Cyan;
            this.lblWhileLus3.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWhileLus3.ForeColor = System.Drawing.Color.Red;
            this.lblWhileLus3.Location = new System.Drawing.Point(283, 41);
            this.lblWhileLus3.Name = "lblWhileLus3";
            this.lblWhileLus3.Size = new System.Drawing.Size(239, 46);
            this.lblWhileLus3.TabIndex = 0;
            this.lblWhileLus3.Text = "While Lus 3";
            // 
            // lbxEenTotTien
            // 
            this.lbxEenTotTien.FormattingEnabled = true;
            this.lbxEenTotTien.ItemHeight = 16;
            this.lbxEenTotTien.Location = new System.Drawing.Point(105, 111);
            this.lbxEenTotTien.Name = "lbxEenTotTien";
            this.lbxEenTotTien.Size = new System.Drawing.Size(189, 212);
            this.lbxEenTotTien.TabIndex = 1;
            // 
            // lbxNegentigTotHonderd
            // 
            this.lbxNegentigTotHonderd.FormattingEnabled = true;
            this.lbxNegentigTotHonderd.ItemHeight = 16;
            this.lbxNegentigTotHonderd.Location = new System.Drawing.Point(333, 111);
            this.lbxNegentigTotHonderd.Name = "lbxNegentigTotHonderd";
            this.lbxNegentigTotHonderd.Size = new System.Drawing.Size(189, 212);
            this.lbxNegentigTotHonderd.TabIndex = 2;
            // 
            // lbxHonderdTotNegentig
            // 
            this.lbxHonderdTotNegentig.FormattingEnabled = true;
            this.lbxHonderdTotNegentig.ItemHeight = 16;
            this.lbxHonderdTotNegentig.Location = new System.Drawing.Point(567, 111);
            this.lbxHonderdTotNegentig.Name = "lbxHonderdTotNegentig";
            this.lbxHonderdTotNegentig.Size = new System.Drawing.Size(189, 212);
            this.lbxHonderdTotNegentig.TabIndex = 3;
            // 
            // btnStatistiek1Tot10
            // 
            this.btnStatistiek1Tot10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStatistiek1Tot10.ForeColor = System.Drawing.Color.Black;
            this.btnStatistiek1Tot10.Location = new System.Drawing.Point(105, 338);
            this.btnStatistiek1Tot10.Name = "btnStatistiek1Tot10";
            this.btnStatistiek1Tot10.Size = new System.Drawing.Size(189, 100);
            this.btnStatistiek1Tot10.TabIndex = 4;
            this.btnStatistiek1Tot10.Text = "Geef Statistiek 1 Tot 10";
            this.btnStatistiek1Tot10.UseVisualStyleBackColor = true;
            this.btnStatistiek1Tot10.Click += new System.EventHandler(this.btnStatistiek1Tot10_Click);
            // 
            // btnStatistiek90Tot100
            // 
            this.btnStatistiek90Tot100.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStatistiek90Tot100.ForeColor = System.Drawing.Color.Black;
            this.btnStatistiek90Tot100.Location = new System.Drawing.Point(333, 338);
            this.btnStatistiek90Tot100.Name = "btnStatistiek90Tot100";
            this.btnStatistiek90Tot100.Size = new System.Drawing.Size(189, 100);
            this.btnStatistiek90Tot100.TabIndex = 5;
            this.btnStatistiek90Tot100.Text = "Geef Statistiek 90 tot 100";
            this.btnStatistiek90Tot100.UseVisualStyleBackColor = true;
            this.btnStatistiek90Tot100.Click += new System.EventHandler(this.btnStatistiek90Tot100_Click);
            // 
            // btnStatistiek100Tot90
            // 
            this.btnStatistiek100Tot90.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStatistiek100Tot90.ForeColor = System.Drawing.Color.Black;
            this.btnStatistiek100Tot90.Location = new System.Drawing.Point(567, 338);
            this.btnStatistiek100Tot90.Name = "btnStatistiek100Tot90";
            this.btnStatistiek100Tot90.Size = new System.Drawing.Size(189, 100);
            this.btnStatistiek100Tot90.TabIndex = 6;
            this.btnStatistiek100Tot90.Text = "Geef Statistiek 100 tot 90";
            this.btnStatistiek100Tot90.UseVisualStyleBackColor = true;
            this.btnStatistiek100Tot90.Click += new System.EventHandler(this.btnStatistiek100Tot90_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cyan;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnStatistiek100Tot90);
            this.Controls.Add(this.btnStatistiek90Tot100);
            this.Controls.Add(this.btnStatistiek1Tot10);
            this.Controls.Add(this.lbxHonderdTotNegentig);
            this.Controls.Add(this.lbxNegentigTotHonderd);
            this.Controls.Add(this.lbxEenTotTien);
            this.Controls.Add(this.lblWhileLus3);
            this.ForeColor = System.Drawing.Color.Cyan;
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblWhileLus3;
        private System.Windows.Forms.ListBox lbxEenTotTien;
        private System.Windows.Forms.ListBox lbxNegentigTotHonderd;
        private System.Windows.Forms.ListBox lbxHonderdTotNegentig;
        private System.Windows.Forms.Button btnStatistiek1Tot10;
        private System.Windows.Forms.Button btnStatistiek90Tot100;
        private System.Windows.Forms.Button btnStatistiek100Tot90;
    }
}

