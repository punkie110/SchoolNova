﻿using System;

namespace DoWhileLusJustinMunk1
{
    class program
    {
    static void Main(string[] args)
        {
            int num = 1;
            do
            {
                Console.WriteLine(num);
                num++;
            }while (num <= 5);
            Console.ReadLine();
        }
    }

}
