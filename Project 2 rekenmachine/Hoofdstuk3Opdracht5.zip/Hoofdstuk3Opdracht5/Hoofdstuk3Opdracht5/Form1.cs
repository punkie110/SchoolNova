﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hoofdstuk3Opdracht5
{
    public partial class Form1 : Form
    {
        //deel van een andere aanpak
       // private int aantal = 0;

        public Form1()
        {
            InitializeComponent();
           
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnVoegToe_Click(object sender, EventArgs e)
        {
           //Dit is een andere aanpak
           //aantal++;

            string gradatie = txtInput.Text;
            lbxOutput.Items.Add(gradatie); 
            
            lblAantalNummer.Text = lbxOutput.Items.Count.ToString();
        }

        private void btnMaakLeeg_Click(object sender, EventArgs e)
        {
            lbxOutput.Items.Clear();
            lblAantalNummer.Text = 0.ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
