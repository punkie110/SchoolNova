﻿namespace opdracht2Opleiding
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMaakZin = new System.Windows.Forms.Button();
            this.txtVoornaam = new System.Windows.Forms.TextBox();
            this.txtOpleiding = new System.Windows.Forms.TextBox();
            this.txtHeleZin = new System.Windows.Forms.TextBox();
            this.lblVoornaam = new System.Windows.Forms.Label();
            this.lblOpleiding = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnMaakZin
            // 
            this.btnMaakZin.Location = new System.Drawing.Point(245, 160);
            this.btnMaakZin.Name = "btnMaakZin";
            this.btnMaakZin.Size = new System.Drawing.Size(287, 30);
            this.btnMaakZin.TabIndex = 0;
            this.btnMaakZin.Text = "Maak Zin!";
            this.btnMaakZin.UseVisualStyleBackColor = true;
            this.btnMaakZin.Click += new System.EventHandler(this.btnMaakZin_Click);
            // 
            // txtVoornaam
            // 
            this.txtVoornaam.Location = new System.Drawing.Point(349, 73);
            this.txtVoornaam.Name = "txtVoornaam";
            this.txtVoornaam.Size = new System.Drawing.Size(141, 22);
            this.txtVoornaam.TabIndex = 1;
            // 
            // txtOpleiding
            // 
            this.txtOpleiding.Location = new System.Drawing.Point(349, 115);
            this.txtOpleiding.Name = "txtOpleiding";
            this.txtOpleiding.Size = new System.Drawing.Size(140, 22);
            this.txtOpleiding.TabIndex = 2;
            // 
            // txtHeleZin
            // 
            this.txtHeleZin.Location = new System.Drawing.Point(273, 214);
            this.txtHeleZin.Multiline = true;
            this.txtHeleZin.Name = "txtHeleZin";
            this.txtHeleZin.Size = new System.Drawing.Size(259, 64);
            this.txtHeleZin.TabIndex = 3;
            this.txtHeleZin.TextChanged += new System.EventHandler(this.txtHeleZin_TextChanged);
            // 
            // lblVoornaam
            // 
            this.lblVoornaam.AutoSize = true;
            this.lblVoornaam.Location = new System.Drawing.Point(270, 76);
            this.lblVoornaam.Name = "lblVoornaam";
            this.lblVoornaam.Size = new System.Drawing.Size(73, 16);
            this.lblVoornaam.TabIndex = 4;
            this.lblVoornaam.Text = "Voornaam:";
            this.lblVoornaam.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblOpleiding
            // 
            this.lblOpleiding.AutoSize = true;
            this.lblOpleiding.Location = new System.Drawing.Point(275, 118);
            this.lblOpleiding.Name = "lblOpleiding";
            this.lblOpleiding.Size = new System.Drawing.Size(68, 16);
            this.lblOpleiding.TabIndex = 5;
            this.lblOpleiding.Text = "Opleiding:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblOpleiding);
            this.Controls.Add(this.lblVoornaam);
            this.Controls.Add(this.txtHeleZin);
            this.Controls.Add(this.txtOpleiding);
            this.Controls.Add(this.txtVoornaam);
            this.Controls.Add(this.btnMaakZin);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnMaakZin;
        private System.Windows.Forms.TextBox txtVoornaam;
        private System.Windows.Forms.TextBox txtOpleiding;
        private System.Windows.Forms.TextBox txtHeleZin;
        private System.Windows.Forms.Label lblVoornaam;
        private System.Windows.Forms.Label lblOpleiding;
    }
}

