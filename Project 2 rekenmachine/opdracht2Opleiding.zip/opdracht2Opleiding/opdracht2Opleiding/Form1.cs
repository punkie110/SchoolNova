﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace opdracht2Opleiding
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnMaakZin_Click(object sender, EventArgs e)
        {
            string varVoornaam = txtVoornaam.Text;
            string varOpleiding = txtOpleiding.Text;
            string varZin;

            varZin = "Hallo " + varVoornaam + ". Ik heb zin in deze opleiding: " + varOpleiding;
            txtHeleZin.Text = varZin;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtHeleZin_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
