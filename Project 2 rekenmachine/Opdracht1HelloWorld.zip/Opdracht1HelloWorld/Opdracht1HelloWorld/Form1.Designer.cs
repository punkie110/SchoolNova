﻿namespace Opdracht1HelloWorld
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.printTekst = new System.Windows.Forms.ListBox();
            this.voerTekstUit = new System.Windows.Forms.Button();
            this.invoerTekst = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // printTekst
            // 
            this.printTekst.FormattingEnabled = true;
            this.printTekst.ItemHeight = 16;
            this.printTekst.Location = new System.Drawing.Point(328, 261);
            this.printTekst.Name = "printTekst";
            this.printTekst.Size = new System.Drawing.Size(120, 84);
            this.printTekst.TabIndex = 0;
            // 
            // voerTekstUit
            // 
            this.voerTekstUit.Location = new System.Drawing.Point(353, 140);
            this.voerTekstUit.Name = "voerTekstUit";
            this.voerTekstUit.Size = new System.Drawing.Size(75, 23);
            this.voerTekstUit.TabIndex = 1;
            this.voerTekstUit.Text = "button1";
            this.voerTekstUit.UseVisualStyleBackColor = true;
            this.voerTekstUit.Click += new System.EventHandler(this.button1_Click);
            // 
            // invoerTekst
            // 
            this.invoerTekst.Location = new System.Drawing.Point(328, 209);
            this.invoerTekst.Name = "invoerTekst";
            this.invoerTekst.Size = new System.Drawing.Size(100, 22);
            this.invoerTekst.TabIndex = 2;
            this.invoerTekst.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.invoerTekst);
            this.Controls.Add(this.voerTekstUit);
            this.Controls.Add(this.printTekst);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox printTekst;
        private System.Windows.Forms.Button voerTekstUit;
        private System.Windows.Forms.TextBox invoerTekst;
    }
}

