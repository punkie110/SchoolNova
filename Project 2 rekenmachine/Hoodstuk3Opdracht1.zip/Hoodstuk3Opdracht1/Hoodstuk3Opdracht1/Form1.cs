﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hoodstuk3Opdracht1
{
    public partial class frmListBoxOpdrachten : Form
    {
        public frmListBoxOpdrachten()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void frmListBoxOpdrachten_Load(object sender, EventArgs e)
        {
            string varWoord = "Makkelijk";
            lstMakkelijk.Items.Add(varWoord);
        }
    }
}
