﻿namespace Hoodstuk_5_Opdracht_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBereken = new System.Windows.Forms.Button();
            this.txtStraal = new System.Windows.Forms.TextBox();
            this.txtOppervlakte = new System.Windows.Forms.TextBox();
            this.txtOmtrek = new System.Windows.Forms.TextBox();
            this.lblStraal = new System.Windows.Forms.Label();
            this.lblOmtrek = new System.Windows.Forms.Label();
            this.lblOppervlakte = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnBereken
            // 
            this.btnBereken.Location = new System.Drawing.Point(459, 195);
            this.btnBereken.Name = "btnBereken";
            this.btnBereken.Size = new System.Drawing.Size(250, 62);
            this.btnBereken.TabIndex = 0;
            this.btnBereken.Text = "Bereken";
            this.btnBereken.UseVisualStyleBackColor = true;
            this.btnBereken.Click += new System.EventHandler(this.btnBereken_Click);
            // 
            // txtStraal
            // 
            this.txtStraal.Location = new System.Drawing.Point(223, 38);
            this.txtStraal.Name = "txtStraal";
            this.txtStraal.Size = new System.Drawing.Size(224, 22);
            this.txtStraal.TabIndex = 1;
            this.txtStraal.TextChanged += new System.EventHandler(this.txtStraal_TextChanged);
            // 
            // txtOppervlakte
            // 
            this.txtOppervlakte.Location = new System.Drawing.Point(223, 135);
            this.txtOppervlakte.Name = "txtOppervlakte";
            this.txtOppervlakte.ReadOnly = true;
            this.txtOppervlakte.Size = new System.Drawing.Size(224, 22);
            this.txtOppervlakte.TabIndex = 2;
            // 
            // txtOmtrek
            // 
            this.txtOmtrek.Location = new System.Drawing.Point(223, 86);
            this.txtOmtrek.Name = "txtOmtrek";
            this.txtOmtrek.ReadOnly = true;
            this.txtOmtrek.Size = new System.Drawing.Size(224, 22);
            this.txtOmtrek.TabIndex = 3;
            // 
            // lblStraal
            // 
            this.lblStraal.AutoSize = true;
            this.lblStraal.Location = new System.Drawing.Point(156, 41);
            this.lblStraal.Name = "lblStraal";
            this.lblStraal.Size = new System.Drawing.Size(42, 16);
            this.lblStraal.TabIndex = 4;
            this.lblStraal.Text = "Straal";
            this.lblStraal.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblOmtrek
            // 
            this.lblOmtrek.AutoSize = true;
            this.lblOmtrek.Location = new System.Drawing.Point(156, 86);
            this.lblOmtrek.Name = "lblOmtrek";
            this.lblOmtrek.Size = new System.Drawing.Size(50, 16);
            this.lblOmtrek.TabIndex = 5;
            this.lblOmtrek.Text = "Omtrek";
            this.lblOmtrek.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // lblOppervlakte
            // 
            this.lblOppervlakte.AutoSize = true;
            this.lblOppervlakte.Location = new System.Drawing.Point(136, 138);
            this.lblOppervlakte.Name = "lblOppervlakte";
            this.lblOppervlakte.Size = new System.Drawing.Size(81, 16);
            this.lblOppervlakte.TabIndex = 6;
            this.lblOppervlakte.Text = "Oppervlakte";
            this.lblOppervlakte.Click += new System.EventHandler(this.label2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblOppervlakte);
            this.Controls.Add(this.lblOmtrek);
            this.Controls.Add(this.lblStraal);
            this.Controls.Add(this.txtOmtrek);
            this.Controls.Add(this.txtOppervlakte);
            this.Controls.Add(this.txtStraal);
            this.Controls.Add(this.btnBereken);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBereken;
        private System.Windows.Forms.TextBox txtStraal;
        private System.Windows.Forms.TextBox txtOppervlakte;
        private System.Windows.Forms.TextBox txtOmtrek;
        private System.Windows.Forms.Label lblStraal;
        private System.Windows.Forms.Label lblOmtrek;
        private System.Windows.Forms.Label lblOppervlakte;
    }
}

