﻿namespace opdracht2._2Opleiding
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblVoornaam = new System.Windows.Forms.Label();
            this.lblWoonplaats = new System.Windows.Forms.Label();
            this.lblReistijd = new System.Windows.Forms.Label();
            this.txtVoornaam = new System.Windows.Forms.TextBox();
            this.txtWoonplaats = new System.Windows.Forms.TextBox();
            this.txtReistijd = new System.Windows.Forms.TextBox();
            this.btnMaakZin = new System.Windows.Forms.Button();
            this.txtHeleZin = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblVoornaam
            // 
            this.lblVoornaam.AutoSize = true;
            this.lblVoornaam.Location = new System.Drawing.Point(280, 96);
            this.lblVoornaam.Name = "lblVoornaam";
            this.lblVoornaam.Size = new System.Drawing.Size(73, 16);
            this.lblVoornaam.TabIndex = 0;
            this.lblVoornaam.Text = "Voornaam:";
            this.lblVoornaam.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblWoonplaats
            // 
            this.lblWoonplaats.AutoSize = true;
            this.lblWoonplaats.Location = new System.Drawing.Point(270, 144);
            this.lblWoonplaats.Name = "lblWoonplaats";
            this.lblWoonplaats.Size = new System.Drawing.Size(83, 16);
            this.lblWoonplaats.TabIndex = 1;
            this.lblWoonplaats.Text = "Woonplaats:";
            // 
            // lblReistijd
            // 
            this.lblReistijd.AutoSize = true;
            this.lblReistijd.Location = new System.Drawing.Point(270, 193);
            this.lblReistijd.Name = "lblReistijd";
            this.lblReistijd.Size = new System.Drawing.Size(244, 16);
            this.lblReistijd.TabIndex = 2;
            this.lblReistijd.Text = "Reistijd langer of korter dan een half uur:";
            this.lblReistijd.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // txtVoornaam
            // 
            this.txtVoornaam.Location = new System.Drawing.Point(377, 96);
            this.txtVoornaam.Name = "txtVoornaam";
            this.txtVoornaam.Size = new System.Drawing.Size(137, 22);
            this.txtVoornaam.TabIndex = 3;
            // 
            // txtWoonplaats
            // 
            this.txtWoonplaats.Location = new System.Drawing.Point(377, 141);
            this.txtWoonplaats.Name = "txtWoonplaats";
            this.txtWoonplaats.Size = new System.Drawing.Size(137, 22);
            this.txtWoonplaats.TabIndex = 4;
            // 
            // txtReistijd
            // 
            this.txtReistijd.Location = new System.Drawing.Point(377, 228);
            this.txtReistijd.Name = "txtReistijd";
            this.txtReistijd.Size = new System.Drawing.Size(137, 22);
            this.txtReistijd.TabIndex = 5;
            // 
            // btnMaakZin
            // 
            this.btnMaakZin.Location = new System.Drawing.Point(273, 284);
            this.btnMaakZin.Name = "btnMaakZin";
            this.btnMaakZin.Size = new System.Drawing.Size(241, 23);
            this.btnMaakZin.TabIndex = 6;
            this.btnMaakZin.Text = "Maak Zin!";
            this.btnMaakZin.UseVisualStyleBackColor = true;
            this.btnMaakZin.Click += new System.EventHandler(this.btnMaakZin_Click);
            // 
            // txtHeleZin
            // 
            this.txtHeleZin.Location = new System.Drawing.Point(273, 328);
            this.txtHeleZin.Multiline = true;
            this.txtHeleZin.Name = "txtHeleZin";
            this.txtHeleZin.Size = new System.Drawing.Size(241, 59);
            this.txtHeleZin.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtHeleZin);
            this.Controls.Add(this.btnMaakZin);
            this.Controls.Add(this.txtReistijd);
            this.Controls.Add(this.txtWoonplaats);
            this.Controls.Add(this.txtVoornaam);
            this.Controls.Add(this.lblReistijd);
            this.Controls.Add(this.lblWoonplaats);
            this.Controls.Add(this.lblVoornaam);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblVoornaam;
        private System.Windows.Forms.Label lblWoonplaats;
        private System.Windows.Forms.Label lblReistijd;
        private System.Windows.Forms.TextBox txtVoornaam;
        private System.Windows.Forms.TextBox txtWoonplaats;
        private System.Windows.Forms.TextBox txtReistijd;
        private System.Windows.Forms.Button btnMaakZin;
        private System.Windows.Forms.TextBox txtHeleZin;
    }
}

