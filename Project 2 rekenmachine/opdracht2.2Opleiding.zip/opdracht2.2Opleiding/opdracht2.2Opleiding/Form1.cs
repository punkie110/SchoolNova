﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace opdracht2._2Opleiding
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void btnMaakZin_Click(object sender, EventArgs e)
        {
            txtHeleZin.Text = ($"Mijn voornaam is {txtVoornaam.Text}. Ik woon in {txtWoonplaats.Text}. Ik heb een reistijd {txtReistijd.Text} dan een half uur naar school");
        }
    }
}
