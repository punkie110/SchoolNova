﻿namespace Hoofdstuk_5_Opdracht_3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBereken = new System.Windows.Forms.Button();
            this.txtTemp = new System.Windows.Forms.TextBox();
            this.txtGrdnKelv = new System.Windows.Forms.TextBox();
            this.txtGrdnFahr = new System.Windows.Forms.TextBox();
            this.lblTemperatuur = new System.Windows.Forms.Label();
            this.lblGradenFahrenheit = new System.Windows.Forms.Label();
            this.lblGradenKelvin = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnBereken
            // 
            this.btnBereken.Location = new System.Drawing.Point(476, 286);
            this.btnBereken.Name = "btnBereken";
            this.btnBereken.Size = new System.Drawing.Size(183, 44);
            this.btnBereken.TabIndex = 0;
            this.btnBereken.Text = "Bereken";
            this.btnBereken.UseVisualStyleBackColor = true;
            this.btnBereken.Click += new System.EventHandler(this.btnBereken_Click);
            // 
            // txtTemp
            // 
            this.txtTemp.Location = new System.Drawing.Point(432, 95);
            this.txtTemp.Name = "txtTemp";
            this.txtTemp.Size = new System.Drawing.Size(227, 22);
            this.txtTemp.TabIndex = 1;
            // 
            // txtGrdnKelv
            // 
            this.txtGrdnKelv.Location = new System.Drawing.Point(432, 213);
            this.txtGrdnKelv.Name = "txtGrdnKelv";
            this.txtGrdnKelv.ReadOnly = true;
            this.txtGrdnKelv.Size = new System.Drawing.Size(227, 22);
            this.txtGrdnKelv.TabIndex = 2;
            // 
            // txtGrdnFahr
            // 
            this.txtGrdnFahr.Location = new System.Drawing.Point(432, 151);
            this.txtGrdnFahr.Name = "txtGrdnFahr";
            this.txtGrdnFahr.ReadOnly = true;
            this.txtGrdnFahr.Size = new System.Drawing.Size(227, 22);
            this.txtGrdnFahr.TabIndex = 3;
            // 
            // lblTemperatuur
            // 
            this.lblTemperatuur.AutoSize = true;
            this.lblTemperatuur.Location = new System.Drawing.Point(294, 98);
            this.lblTemperatuur.Name = "lblTemperatuur";
            this.lblTemperatuur.Size = new System.Drawing.Size(84, 16);
            this.lblTemperatuur.TabIndex = 4;
            this.lblTemperatuur.Text = "Temperatuur";
            // 
            // lblGradenFahrenheit
            // 
            this.lblGradenFahrenheit.AutoSize = true;
            this.lblGradenFahrenheit.Location = new System.Drawing.Point(294, 151);
            this.lblGradenFahrenheit.Name = "lblGradenFahrenheit";
            this.lblGradenFahrenheit.Size = new System.Drawing.Size(118, 16);
            this.lblGradenFahrenheit.TabIndex = 5;
            this.lblGradenFahrenheit.Text = "Graden Fahrenheit";
            // 
            // lblGradenKelvin
            // 
            this.lblGradenKelvin.AutoSize = true;
            this.lblGradenKelvin.Location = new System.Drawing.Point(294, 219);
            this.lblGradenKelvin.Name = "lblGradenKelvin";
            this.lblGradenKelvin.Size = new System.Drawing.Size(91, 16);
            this.lblGradenKelvin.TabIndex = 6;
            this.lblGradenKelvin.Text = "Graden Kelvin";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblGradenKelvin);
            this.Controls.Add(this.lblGradenFahrenheit);
            this.Controls.Add(this.lblTemperatuur);
            this.Controls.Add(this.txtGrdnFahr);
            this.Controls.Add(this.txtGrdnKelv);
            this.Controls.Add(this.txtTemp);
            this.Controls.Add(this.btnBereken);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBereken;
        private System.Windows.Forms.TextBox txtTemp;
        private System.Windows.Forms.TextBox txtGrdnKelv;
        private System.Windows.Forms.TextBox txtGrdnFahr;
        private System.Windows.Forms.Label lblTemperatuur;
        private System.Windows.Forms.Label lblGradenFahrenheit;
        private System.Windows.Forms.Label lblGradenKelvin;
    }
}

