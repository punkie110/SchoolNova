﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication4_voorbeeld
{
    class Program
    {
        static void Main(string[] args)
        {
            // beginwaarde 
            int a = 10;
            int b = 30;
            int c = 20;

            // gebruik de juiste operator voor het juiste resultaat
            // a vermenigvuligen met 3;
            a = a * 3;
            // b delen door 2
            b = b / 3;
            // c ophogen met 2
            c = c + 2;
             Console.WriteLine(a);
            Console.WriteLine(b);
            Console.WriteLine(c);
            Console.ReadLine();
            
          
        }
    }
}
