﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hoofdstuk3Opdracht4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVoegToe_Click(object sender, EventArgs e)
        {
            string woorden = txtInput.Text;
            lbxOutput.Items.Add(woorden);
        }

        private void btnMaakLeeg_Click(object sender, EventArgs e)
        {
            lbxOutput.Items.Clear();
        }
    }
}
