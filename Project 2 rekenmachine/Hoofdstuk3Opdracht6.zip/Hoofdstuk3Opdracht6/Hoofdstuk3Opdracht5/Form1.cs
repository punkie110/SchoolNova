﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Management.Instrumentation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//deze file heet opdracht 5 per ongeluk in sommige files, maar dit is opdracht 6
namespace Hoofdstuk3Opdracht6
{
    public partial class Form1 : Form
    {
        //deel van een andere aanpak
       // private int aantal = 0;

        public Form1()
        {
            InitializeComponent();
           
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnVoegToe_Click(object sender, EventArgs e)
        {
           //Dit is een andere aanpak
           //aantal++;
           //ik heb voor opdracht 6 de number count er in gelaten en aangepast op het nieuwe model als extraatje :)
            string gradatie = txtInput.Text;
            lbxOutput.Items.Add(gradatie); 
            
            lblAantalNummer.Text = lbxOutput.Items.Count.ToString();
        }

        private void btnMaakLeeg_Click(object sender, EventArgs e)
        {
            lbxOutput.Items.Clear();
            lblAantalNummer.Text = 0.ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void lblGeselecteerde_Click(object sender, EventArgs e)
        {

        }

        private void lbxOutput_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lbxOutput.SelectedItem != null)
            {
                lblGeselecteerde.Text = lbxOutput.SelectedItem.ToString();
            }
            else
            {
                lblGeselecteerde.Text = "";
            }
        }

        private void btnGeselcteerdeVerwijderen_Click(object sender, EventArgs e)
        {
            if (lbxOutput.SelectedItem != null)
            {
                lbxOutput.Items.RemoveAt(lbxOutput.SelectedIndex);
                lblAantalNummer.Text = lbxOutput.Items.Count.ToString();
            }
        }
    }
}
