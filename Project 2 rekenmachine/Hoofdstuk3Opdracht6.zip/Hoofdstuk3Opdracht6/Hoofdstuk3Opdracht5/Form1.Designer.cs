﻿namespace Hoofdstuk3Opdracht6
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMaakLeeg = new System.Windows.Forms.Button();
            this.btnVoegToe = new System.Windows.Forms.Button();
            this.lbxOutput = new System.Windows.Forms.ListBox();
            this.txtInput = new System.Windows.Forms.TextBox();
            this.lblAantalItems = new System.Windows.Forms.Label();
            this.lblAantalNummer = new System.Windows.Forms.Label();
            this.lblToeTeVoegenNaam = new System.Windows.Forms.Label();
            this.btnGeselcteerdeVerwijderen = new System.Windows.Forms.Button();
            this.lblGeselecteerde = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnMaakLeeg
            // 
            this.btnMaakLeeg.Location = new System.Drawing.Point(584, 81);
            this.btnMaakLeeg.Name = "btnMaakLeeg";
            this.btnMaakLeeg.Size = new System.Drawing.Size(181, 69);
            this.btnMaakLeeg.TabIndex = 0;
            this.btnMaakLeeg.Text = "Maak leeg";
            this.btnMaakLeeg.UseVisualStyleBackColor = true;
            this.btnMaakLeeg.Click += new System.EventHandler(this.btnMaakLeeg_Click);
            // 
            // btnVoegToe
            // 
            this.btnVoegToe.Location = new System.Drawing.Point(100, 106);
            this.btnVoegToe.Name = "btnVoegToe";
            this.btnVoegToe.Size = new System.Drawing.Size(181, 69);
            this.btnVoegToe.TabIndex = 1;
            this.btnVoegToe.Text = "voeg toe";
            this.btnVoegToe.UseVisualStyleBackColor = true;
            this.btnVoegToe.Click += new System.EventHandler(this.btnVoegToe_Click);
            // 
            // lbxOutput
            // 
            this.lbxOutput.FormattingEnabled = true;
            this.lbxOutput.ItemHeight = 16;
            this.lbxOutput.Items.AddRange(new object[] {
            "Albert",
            "Johannes",
            "Alfred",
            "Shane",
            "Dwayne"});
            this.lbxOutput.Location = new System.Drawing.Point(287, 146);
            this.lbxOutput.Name = "lbxOutput";
            this.lbxOutput.Size = new System.Drawing.Size(246, 292);
            this.lbxOutput.TabIndex = 2;
            this.lbxOutput.SelectedIndexChanged += new System.EventHandler(this.lbxOutput_SelectedIndexChanged);
            // 
            // txtInput
            // 
            this.txtInput.Location = new System.Drawing.Point(100, 72);
            this.txtInput.Name = "txtInput";
            this.txtInput.Size = new System.Drawing.Size(181, 22);
            this.txtInput.TabIndex = 3;
            // 
            // lblAantalItems
            // 
            this.lblAantalItems.AutoSize = true;
            this.lblAantalItems.Location = new System.Drawing.Point(366, 43);
            this.lblAantalItems.Name = "lblAantalItems";
            this.lblAantalItems.Size = new System.Drawing.Size(80, 16);
            this.lblAantalItems.TabIndex = 4;
            this.lblAantalItems.Text = "Aantal Items";
            this.lblAantalItems.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblAantalNummer
            // 
            this.lblAantalNummer.AutoSize = true;
            this.lblAantalNummer.Location = new System.Drawing.Point(414, 81);
            this.lblAantalNummer.Name = "lblAantalNummer";
            this.lblAantalNummer.Size = new System.Drawing.Size(0, 16);
            this.lblAantalNummer.TabIndex = 5;
            // 
            // lblToeTeVoegenNaam
            // 
            this.lblToeTeVoegenNaam.AutoSize = true;
            this.lblToeTeVoegenNaam.Location = new System.Drawing.Point(125, 43);
            this.lblToeTeVoegenNaam.Name = "lblToeTeVoegenNaam";
            this.lblToeTeVoegenNaam.Size = new System.Drawing.Size(135, 16);
            this.lblToeTeVoegenNaam.TabIndex = 6;
            this.lblToeTeVoegenNaam.Text = "Toe te voegen naam:";
            this.lblToeTeVoegenNaam.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // btnGeselcteerdeVerwijderen
            // 
            this.btnGeselcteerdeVerwijderen.Location = new System.Drawing.Point(583, 330);
            this.btnGeselcteerdeVerwijderen.Name = "btnGeselcteerdeVerwijderen";
            this.btnGeselcteerdeVerwijderen.Size = new System.Drawing.Size(181, 59);
            this.btnGeselcteerdeVerwijderen.TabIndex = 7;
            this.btnGeselcteerdeVerwijderen.Text = "geselecteerde naam verwijderen";
            this.btnGeselcteerdeVerwijderen.UseVisualStyleBackColor = true;
            this.btnGeselcteerdeVerwijderen.Click += new System.EventHandler(this.btnGeselcteerdeVerwijderen_Click);
            // 
            // lblGeselecteerde
            // 
            this.lblGeselecteerde.AutoSize = true;
            this.lblGeselecteerde.Location = new System.Drawing.Point(596, 295);
            this.lblGeselecteerde.Name = "lblGeselecteerde";
            this.lblGeselecteerde.Size = new System.Drawing.Size(0, 16);
            this.lblGeselecteerde.TabIndex = 8;
            this.lblGeselecteerde.Click += new System.EventHandler(this.lblGeselecteerde_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblGeselecteerde);
            this.Controls.Add(this.btnGeselcteerdeVerwijderen);
            this.Controls.Add(this.lblToeTeVoegenNaam);
            this.Controls.Add(this.lblAantalNummer);
            this.Controls.Add(this.lblAantalItems);
            this.Controls.Add(this.txtInput);
            this.Controls.Add(this.lbxOutput);
            this.Controls.Add(this.btnVoegToe);
            this.Controls.Add(this.btnMaakLeeg);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnMaakLeeg;
        private System.Windows.Forms.Button btnVoegToe;
        private System.Windows.Forms.ListBox lbxOutput;
        private System.Windows.Forms.TextBox txtInput;
        private System.Windows.Forms.Label lblAantalItems;
        private System.Windows.Forms.Label lblAantalNummer;
        private System.Windows.Forms.Label lblToeTeVoegenNaam;
        private System.Windows.Forms.Button btnGeselcteerdeVerwijderen;
        private System.Windows.Forms.Label lblGeselecteerde;
    }
}

