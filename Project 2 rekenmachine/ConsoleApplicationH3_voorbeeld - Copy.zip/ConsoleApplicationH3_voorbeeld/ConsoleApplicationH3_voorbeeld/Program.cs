﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplicationH3_voorbeeld
{
    class Program
    {
        static void Main(string[] args)
        {
            byte a = 256;
            long b = 100;
            decimal c = 5.66m;
            String d= "eerste voorbeeld:";
            Console.WriteLine(d+a+""+b+""+c);
            
        }
    }
}
