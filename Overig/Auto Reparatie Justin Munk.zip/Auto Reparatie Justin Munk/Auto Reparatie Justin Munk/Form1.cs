﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Auto_Reparatie_Justin_Munk
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnBereken_Click(object sender, EventArgs e)
        {
            
            if(double.Parse(txtUurloon.Text) < 40)
            {
                double teBetalen = double.Parse(txtGewerkteUren.Text) * double.Parse(txtUurloon.Text) + double.Parse(txtOnderdelenEuros.Text);
                double teBetalenMetMarge = 1.05 * teBetalen;
                txtBetalen.Text = teBetalenMetMarge.ToString();
            }
            else
            {
                double teBetalen = double.Parse(txtGewerkteUren.Text) * double.Parse(txtUurloon.Text) + double.Parse(txtOnderdelenEuros.Text);
                txtBetalen.Text = teBetalen.ToString();
            }
        }
    }
}
