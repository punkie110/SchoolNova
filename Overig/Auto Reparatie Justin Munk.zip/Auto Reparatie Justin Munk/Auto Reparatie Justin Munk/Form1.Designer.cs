﻿namespace Auto_Reparatie_Justin_Munk
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtGewerkteUren = new System.Windows.Forms.TextBox();
            this.txtUurloon = new System.Windows.Forms.TextBox();
            this.lblGewerkteUren = new System.Windows.Forms.Label();
            this.btnBereken = new System.Windows.Forms.Button();
            this.lblUurloon = new System.Windows.Forms.Label();
            this.txtOnderdelenEuros = new System.Windows.Forms.TextBox();
            this.lblOnderdelenEuros = new System.Windows.Forms.Label();
            this.lblBetalen = new System.Windows.Forms.Label();
            this.txtBetalen = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtGewerkteUren
            // 
            this.txtGewerkteUren.Location = new System.Drawing.Point(426, 76);
            this.txtGewerkteUren.Name = "txtGewerkteUren";
            this.txtGewerkteUren.Size = new System.Drawing.Size(111, 22);
            this.txtGewerkteUren.TabIndex = 0;
            // 
            // txtUurloon
            // 
            this.txtUurloon.Location = new System.Drawing.Point(426, 115);
            this.txtUurloon.Name = "txtUurloon";
            this.txtUurloon.Size = new System.Drawing.Size(110, 22);
            this.txtUurloon.TabIndex = 1;
            // 
            // lblGewerkteUren
            // 
            this.lblGewerkteUren.AutoSize = true;
            this.lblGewerkteUren.Location = new System.Drawing.Point(256, 79);
            this.lblGewerkteUren.Name = "lblGewerkteUren";
            this.lblGewerkteUren.Size = new System.Drawing.Size(137, 16);
            this.lblGewerkteUren.TabIndex = 2;
            this.lblGewerkteUren.Text = "Aantal Gewerkte Uren";
            // 
            // btnBereken
            // 
            this.btnBereken.Location = new System.Drawing.Point(294, 196);
            this.btnBereken.Name = "btnBereken";
            this.btnBereken.Size = new System.Drawing.Size(254, 27);
            this.btnBereken.TabIndex = 3;
            this.btnBereken.Text = "Bereken";
            this.btnBereken.UseVisualStyleBackColor = true;
            this.btnBereken.Click += new System.EventHandler(this.btnBereken_Click);
            // 
            // lblUurloon
            // 
            this.lblUurloon.AutoSize = true;
            this.lblUurloon.Location = new System.Drawing.Point(339, 115);
            this.lblUurloon.Name = "lblUurloon";
            this.lblUurloon.Size = new System.Drawing.Size(54, 16);
            this.lblUurloon.TabIndex = 4;
            this.lblUurloon.Text = "Uurloon";
            // 
            // txtOnderdelenEuros
            // 
            this.txtOnderdelenEuros.Location = new System.Drawing.Point(427, 157);
            this.txtOnderdelenEuros.Name = "txtOnderdelenEuros";
            this.txtOnderdelenEuros.Size = new System.Drawing.Size(110, 22);
            this.txtOnderdelenEuros.TabIndex = 5;
            // 
            // lblOnderdelenEuros
            // 
            this.lblOnderdelenEuros.AutoSize = true;
            this.lblOnderdelenEuros.Location = new System.Drawing.Point(262, 157);
            this.lblOnderdelenEuros.Name = "lblOnderdelenEuros";
            this.lblOnderdelenEuros.Size = new System.Drawing.Size(131, 16);
            this.lblOnderdelenEuros.TabIndex = 6;
            this.lblOnderdelenEuros.Text = "Onderdelen in euro\'s";
            // 
            // lblBetalen
            // 
            this.lblBetalen.AutoSize = true;
            this.lblBetalen.Location = new System.Drawing.Point(310, 269);
            this.lblBetalen.Name = "lblBetalen";
            this.lblBetalen.Size = new System.Drawing.Size(72, 16);
            this.lblBetalen.TabIndex = 7;
            this.lblBetalen.Text = "Te betalen";
            // 
            // txtBetalen
            // 
            this.txtBetalen.Location = new System.Drawing.Point(427, 266);
            this.txtBetalen.Name = "txtBetalen";
            this.txtBetalen.ReadOnly = true;
            this.txtBetalen.Size = new System.Drawing.Size(110, 22);
            this.txtBetalen.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtBetalen);
            this.Controls.Add(this.lblBetalen);
            this.Controls.Add(this.lblOnderdelenEuros);
            this.Controls.Add(this.txtOnderdelenEuros);
            this.Controls.Add(this.lblUurloon);
            this.Controls.Add(this.btnBereken);
            this.Controls.Add(this.lblGewerkteUren);
            this.Controls.Add(this.txtUurloon);
            this.Controls.Add(this.txtGewerkteUren);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtGewerkteUren;
        private System.Windows.Forms.TextBox txtUurloon;
        private System.Windows.Forms.Label lblGewerkteUren;
        private System.Windows.Forms.Button btnBereken;
        private System.Windows.Forms.Label lblUurloon;
        private System.Windows.Forms.TextBox txtOnderdelenEuros;
        private System.Windows.Forms.Label lblOnderdelenEuros;
        private System.Windows.Forms.Label lblBetalen;
        private System.Windows.Forms.TextBox txtBetalen;
    }
}

