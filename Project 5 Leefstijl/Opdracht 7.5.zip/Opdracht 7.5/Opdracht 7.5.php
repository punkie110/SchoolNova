<html>
<head>
</head>
<body>
<form name="Temperatuur berekenen" method="post" action="Opdracht 7.5.2.php"><br />
GEEF TEMPERATUUR<br />
<input type="text" name="temperatuur" value=""> <br />
<input type="submit" name="submit" value="Bevestig"> <br />
</form>
</body>
</html>