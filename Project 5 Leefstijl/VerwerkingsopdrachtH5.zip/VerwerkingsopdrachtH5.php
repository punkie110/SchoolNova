<?php
$zon = true;
$wind = 4;

if($wind > 3)
{
echo "Vandaag is het zeilweer.";
}
elseif($zon = true)
{
echo "Vandaag is het strandweer.";
}
else
{
echo "vandaag is het geen strand en geen zeilweer.";
}
?>