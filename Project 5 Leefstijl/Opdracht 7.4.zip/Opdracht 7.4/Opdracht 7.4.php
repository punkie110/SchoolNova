<html>
    <head>
</head>
<body>
geef bedrag </br>
<form name ="btw berekenen" method="post" action="Opdracht 7.4.2.php"> </br>
<input type ="text" name = "bedrag" value =""> </br>
<input type ="submit"> </br>
</form>
</body>
</html>