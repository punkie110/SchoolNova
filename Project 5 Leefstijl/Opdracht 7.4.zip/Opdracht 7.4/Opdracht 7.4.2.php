<?php
echo "het bedrag inclusief btw </br>";
echo $_POST["bedrag"] * 1.06;



?> 