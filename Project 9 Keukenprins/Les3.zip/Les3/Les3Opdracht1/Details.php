<?php
$data = $_POST["content"];
echo $data;
?>